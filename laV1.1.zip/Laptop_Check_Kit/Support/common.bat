@echo off
REM ============================================================
REM  Laptop Check Kit - Common functions
REM  This file is called by other scripts. Do not run directly.
REM ============================================================

set "KIT_ROOT=%~dp0.."
for %%I in ("%KIT_ROOT%") do set "KIT_ROOT=%%~fI"
set "REPORTS_DIR=%KIT_ROOT%\Reports"
set "SUPPORT_DIR=%KIT_ROOT%\Support"

if not exist "%REPORTS_DIR%" (
    mkdir "%REPORTS_DIR%" 2>nul
    if errorlevel 1 (
        echo [ERROR] Cannot create Reports folder: %REPORTS_DIR%
        exit /b 1
    )
)

goto :eof

:CheckAdmin
net session >nul 2>&1
if errorlevel 1 (
    set "IS_ADMIN=0"
) else (
    set "IS_ADMIN=1"
)
goto :eof

:Timestamp
for /f "tokens=2 delims==" %%a in ('wmic os get localdatetime /value 2^>nul') do set "dt=%%a"
if defined dt (
    set "TIMESTAMP=%dt:~0,4%-%dt:~4,2%-%dt:~6,2%_%dt:~8,2%-%dt:~10,2%-%dt:~12,2%"
) else (
    set "TIMESTAMP=%date:~-4,4%-%date:~-10,2%-%date:~-7,2%_%time:~0,2%-%time:~3,2%-%time:~6,2%"
    set "TIMESTAMP=%TIMESTAMP: =0%"
)
goto :eof

:PauseAndReturn
echo.
echo Press any key to return to the menu...
pause >nul
goto :eof
