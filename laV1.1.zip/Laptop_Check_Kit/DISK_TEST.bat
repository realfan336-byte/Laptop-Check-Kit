@echo off
setlocal EnableDelayedExpansion
title Laptop Check Kit - Disk Checks

call "%~dp0Support\common.bat"
if errorlevel 1 (
    echo [ERROR] Cannot load common support file.
    pause
    exit /b 1
)

call :Timestamp
set "REPORT=%REPORTS_DIR%\Disk_Test_%TIMESTAMP%.txt"

echo ============================================================
echo   DISK CHECKS (READ-ONLY)
echo ============================================================
echo.
echo This will:
echo   - List logical drives, filesystem, size, free space
echo   - Run chkdsk in READ-ONLY mode (no /f, no /r, no repair)
echo   - Attempt to query physical disk health via PowerShell
echo     (many systems do not expose SMART/health data)
echo.
echo SAFETY: No automatic repair, format, or repartition.
echo.
echo Continue? (Y/N)
set /p "CONFIRM= "
if /i not "%CONFIRM%"=="Y" (
    echo Cancelled.
    call :PauseAndReturn
    exit /b 0
)

(
    echo Laptop Check Kit - Disk Check Report
    echo Generated: %date% %time%
    echo Mode: READ-ONLY (no repair switches)
    echo ============================================================
    echo.
) > "%REPORT%"

echo.
echo [1/3] Listing logical drives...
echo ----- Logical Drives ----- >> "%REPORT%"
wmic logicaldisk get DeviceID,DriveType,FileSystem,Size,FreeSpace,VolumeName /format:list >> "%REPORT%" 2>&1
echo. >> "%REPORT%"

echo Detected drives:
wmic logicaldisk get DeviceID,FileSystem,Size,FreeSpace 2>nul

echo.
echo [2/3] Running read-only chkdsk on each fixed drive...
echo (This may take several minutes per drive)
echo ----- Read-only chkdsk ----- >> "%REPORT%"

for /f "skip=1 tokens=1" %%d in ('wmic logicaldisk where "DriveType=3" get DeviceID 2^>nul') do (
    set "DRV=%%d"
    if defined DRV (
        set "DRV=!DRV: =!"
        if not "!DRV!"=="" (
            echo.
            echo Checking !DRV! (read-only)...
            echo. >> "%REPORT%"
            echo === chkdsk !DRV! (read-only) === >> "%REPORT%"
            chkdsk !DRV! >> "%REPORT%" 2>&1
            if errorlevel 1 (
                echo [WARN] chkdsk on !DRV! returned a non-zero code. See report.
                echo [WARN] chkdsk non-zero exit for !DRV! >> "%REPORT%"
            ) else (
                echo Finished !DRV!
            )
        )
    )
)

echo.
echo [3/3] Querying physical disk health (if exposed)...
echo ----- Physical Disk Health (PowerShell) ----- >> "%REPORT%"
powershell -NoProfile -Command ^
    "try { " ^
    "  Get-PhysicalDisk | Select-Object FriendlyName,MediaType,HealthStatus,OperationalStatus,Size | Format-List | Out-String -Width 200 " ^
    "} catch { " ^
    "  'PowerShell Get-PhysicalDisk not available or failed: ' + $_.Exception.Message " ^
    "}" >> "%REPORT%" 2>&1

if errorlevel 1 (
    echo [INFO] Physical disk health query failed or is unsupported on this system.
    echo [INFO] Many consumer systems do not expose health status to Windows.
    echo [INFO] Health query unavailable or failed. >> "%REPORT%"
) else (
    echo Physical disk query completed (see report for details).
)

echo.
echo ============================================================
echo   Disk checks finished.
echo   Report: %REPORT%
echo ============================================================
echo.
echo Notes:
echo - chkdsk read-only reports problems but does NOT fix them.
echo - A clean chkdsk does not guarantee the drive will never fail.
echo - Physical health data is often unavailable without special
echo   tools or manufacturer software.
echo.
start notepad "%REPORT%"
call :PauseAndReturn
exit /b 0
