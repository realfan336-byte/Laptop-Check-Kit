@echo off
setlocal EnableDelayedExpansion
title Laptop Check Kit - Start Here

REM Work relative to this script's location (any drive/folder)
set "KIT_ROOT=%~dp0"
if "%KIT_ROOT:~-1%"=="\" set "KIT_ROOT=%KIT_ROOT:~0,-1%"

cls
echo ============================================================
echo          LAPTOP CHECK KIT
echo          Beginner Entry Point
echo ============================================================
echo.
echo Kit location:
echo   %KIT_ROOT%
echo.

REM Basic structure check
set "MISSING=0"
if not exist "%KIT_ROOT%\Support\common.bat" (
    echo [ERROR] Support\common.bat is missing.
    set /a MISSING+=1
)
if not exist "%KIT_ROOT%\ALL_TESTS.bat" (
    echo [ERROR] ALL_TESTS.bat is missing.
    set /a MISSING+=1
)
if not exist "%KIT_ROOT%\Reports" (
    echo Creating Reports folder...
    mkdir "%KIT_ROOT%\Reports" 2>nul
)

if %MISSING% GTR 0 (
    echo.
    echo Critical files are missing. The kit cannot run properly.
    echo Please re-extract the ZIP completely.
    echo.
    pause
    exit /b 1
)

echo Checking Windows version...
ver
echo.

echo Detecting basic environment...
echo OS Architecture:
wmic os get OSArchitecture /value 2>nul | findstr "="
echo.

echo ============================================================
echo   READY
echo ============================================================
echo.
echo Recommended first steps:
echo   1. Read README.txt (opens next)
echo   2. Use the main menu (ALL_TESTS.bat)
echo.
echo Opening README.txt...
start notepad "%KIT_ROOT%\README.txt"
timeout /t 2 >nul

echo.
echo Launching main menu...
call "%KIT_ROOT%\ALL_TESTS.bat"
exit /b 0
