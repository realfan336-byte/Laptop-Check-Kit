@echo off
setlocal EnableDelayedExpansion
title Laptop Check Kit - File and Dependency Check

set "KIT_ROOT=%~dp0"
if "%KIT_ROOT:~-1%"=="\" set "KIT_ROOT=%KIT_ROOT:~0,-1%"

echo ============================================================
echo   KIT FILE AND DEPENDENCY CHECK
echo ============================================================
echo.
echo Checking required files and folders relative to:
echo   %KIT_ROOT%
echo.

set "MISSING=0"
set "OK=0"

call :CheckFile "START_HERE.bat"
call :CheckFile "ALL_TESTS.bat"
call :CheckFile "CPU_TEST.bat"
call :CheckFile "RAM_TEST.bat"
call :CheckFile "DISK_TEST.bat"
call :CheckFile "SYSTEM_INFO.bat"
call :CheckFile "BATTERY_TEST.bat"
call :CheckFile "NETWORK_TEST.bat"
call :CheckFile "WINDOWS_HEALTH_TEST.bat"
call :CheckFile "EVENT_LOG_TEST.bat"
call :CheckFile "CHECK_FILES.bat"
call :CheckFile "README.txt"
call :CheckFile "LICENSE.txt"
call :CheckFile "CRASH_DEMO.bat"
call :CheckDir  "Reports"
call :CheckDir  "Support"
call :CheckFile "Support\common.bat"

echo.
echo ============================================================
echo   Summary
echo ============================================================
echo   Present : %OK%
echo   Missing : %MISSING%
echo.

if %MISSING% GTR 0 (
    echo [ERROR] One or more required files or folders are missing.
    echo The kit may not work correctly until they are restored.
    echo Do not invent or create fake replacements.
) else (
    echo All expected kit files and folders are present.
)

echo.
echo Checking basic Windows tools availability...
echo.

where systeminfo >nul 2>&1 && echo [OK] systeminfo || echo [MISSING] systeminfo
where wmic >nul 2>&1 && echo [OK] wmic || echo [MISSING] wmic
where powershell >nul 2>&1 && echo [OK] powershell || echo [MISSING] powershell
where chkdsk >nul 2>&1 && echo [OK] chkdsk || echo [MISSING] chkdsk
where mdsched >nul 2>&1 && echo [OK] mdsched || echo [MISSING] mdsched
where powercfg >nul 2>&1 && echo [OK] powercfg || echo [MISSING] powercfg
where wevtutil >nul 2>&1 && echo [OK] wevtutil || echo [MISSING] wevtutil
where sfc >nul 2>&1 && echo [OK] sfc || echo [MISSING] sfc
where DISM >nul 2>&1 && echo [OK] DISM || echo [MISSING] DISM
where ipconfig >nul 2>&1 && echo [OK] ipconfig || echo [MISSING] ipconfig
where ping >nul 2>&1 && echo [OK] ping || echo [MISSING] ping

echo.
echo Press any key to exit...
pause >nul
exit /b 0

:CheckFile
set "F=%~1"
if exist "%KIT_ROOT%\%F%" (
    echo [OK]      %F%
    set /a OK+=1
) else (
    echo [MISSING] %F%
    set /a MISSING+=1
)
goto :eof

:CheckDir
set "D=%~1"
if exist "%KIT_ROOT%\%D%\" (
    echo [OK]      %D%\
    set /a OK+=1
) else (
    echo [MISSING] %D%\
    set /a MISSING+=1
)
goto :eof
