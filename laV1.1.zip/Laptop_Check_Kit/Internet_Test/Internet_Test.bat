@echo off
setlocal EnableDelayedExpansion
title Bacon Windows Tools - Internet Test
color 0A

REM ============================================================
REM  Internet_Test.bat
REM  Network adapter, gateway, DNS, and connectivity checks
REM  Creates its own folder and Reports subfolder if missing
REM ============================================================

set "SCRIPT_DIR=%~dp0"
if "%SCRIPT_DIR:~-1%"=="\" set "SCRIPT_DIR=%SCRIPT_DIR:~0,-1%"

REM Ensure Internet_Test folder exists (the script lives in it)
if not exist "%SCRIPT_DIR%" (
    echo [ERROR] Script directory not found.
    pause
    exit /b 1
)

REM Create Reports subfolder if missing
set "REPORTS=%SCRIPT_DIR%\Reports"
if not exist "%REPORTS%" (
    echo Creating Reports folder...
    mkdir "%REPORTS%" 2>nul
    if errorlevel 1 (
        echo [ERROR] Cannot create Reports folder: %REPORTS%
        pause
        exit /b 1
    )
)

REM Timestamp
for /f "tokens=2 delims==" %%a in ('wmic os get localdatetime /value 2^>nul') do set "dt=%%a"
if defined dt (
    set "TS=%dt:~0,4%-%dt:~4,2%-%dt:~6,2%_%dt:~8,2%-%dt:~10,2%-%dt:~12,2%"
) else (
    set "TS=%date:~-4,4%-%date:~-10,2%-%date:~-7,2%_%time:~0,2%-%time:~3,2%-%time:~6,2%"
    set "TS=%TS: =0%"
)

set "REPORT=%REPORTS%\Internet_Test_%TS%.txt"

echo ============================================================
echo   INTERNET TEST
echo ============================================================
echo.
echo Reports will be saved to:
echo   %REPORT%
echo.

(
    echo Bacon Windows Tools - Internet Test Report
    echo Generated: %date% %time%
    echo Computer: %COMPUTERNAME%
    echo ============================================================
    echo.
) > "%REPORT%"

echo [1/5] Checking required commands...
where ipconfig >nul 2>&1
if errorlevel 1 (
    echo [ERROR] ipconfig not found.
    echo [ERROR] ipconfig missing >> "%REPORT%"
    goto :FINISH
)
where ping >nul 2>&1
if errorlevel 1 (
    echo [ERROR] ping not found.
    echo [ERROR] ping missing >> "%REPORT%"
    goto :FINISH
)
echo Required commands are available.
echo.

echo [2/5] Network adapter configuration...
echo ----- ipconfig /all ----- >> "%REPORT%"
ipconfig /all >> "%REPORT%" 2>&1
echo.
echo Current adapter summary:
ipconfig
echo. >> "%REPORT%"

echo.
echo [3/5] Default gateway detection and test...
set "GATEWAY="
for /f "tokens=2 delims=:" %%g in ('ipconfig ^| findstr /i /c:"Default Gateway"') do (
    set "TEMPG=%%g"
    set "TEMPG=!TEMPG: =!"
    if not "!TEMPG!"=="" if not "!TEMPG!"=="0.0.0.0" (
        if not defined GATEWAY set "GATEWAY=!TEMPG!"
    )
)

if defined GATEWAY (
    echo Detected default gateway: %GATEWAY%
    echo Default gateway: %GATEWAY% >> "%REPORT%"
    echo.
    echo Testing local gateway (ping)...
    echo ----- Gateway ping ----- >> "%REPORT%"
    ping -n 4 %GATEWAY% >> "%REPORT%" 2>&1
    if errorlevel 1 (
        echo [WARN] Gateway did not respond to ping.
        echo Possible causes: firewall, AP isolation, or gateway issue.
        echo [WARN] Gateway ping failed >> "%REPORT%"
        set "GW_OK=0"
    ) else (
        echo Gateway responded.
        echo Gateway responded >> "%REPORT%"
        set "GW_OK=1"
    )
) else (
    echo No default gateway detected.
    echo No default gateway detected >> "%REPORT%"
    set "GW_OK=0"
)
echo. >> "%REPORT%"

echo.
echo [4/5] DNS configuration sample...
echo ----- DNS / nslookup localhost ----- >> "%REPORT%"
nslookup localhost >> "%REPORT%" 2>&1
echo. >> "%REPORT%"

echo.
echo [5/5] External connectivity test (1.1.1.1 - Cloudflare)...
echo Testing external host 1.1.1.1 ...
echo ----- External ping (1.1.1.1) ----- >> "%REPORT%"
ping -n 4 1.1.1.1 >> "%REPORT%" 2>&1
if errorlevel 1 (
    echo [RESULT] External host 1.1.1.1 did NOT respond.
    echo This can mean:
    echo   - No internet connection
    echo   - Firewall / network policy blocking ICMP
    echo   - Temporary routing problem
    echo A failed ping alone does not always prove a complete outage.
    echo [RESULT] External ping failed >> "%REPORT%"
    set "EXT_OK=0"
) else (
    echo [RESULT] External host 1.1.1.1 responded.
    echo Internet connectivity appears present (ICMP level).
    echo [RESULT] External ping succeeded >> "%REPORT%"
    set "EXT_OK=1"
)
echo. >> "%REPORT%"

REM Optional DNS name test
echo.
echo Optional DNS name resolution test (www.microsoft.com)...
echo ----- DNS name test ----- >> "%REPORT%"
nslookup www.microsoft.com >> "%REPORT%" 2>&1
if errorlevel 1 (
    echo [WARN] DNS lookup failed or timed out.
    echo [WARN] DNS lookup failed >> "%REPORT%"
) else (
    echo DNS lookup completed (see report for details).
)

echo.
echo ============================================================
echo   SUMMARY
echo ============================================================
if "%GW_OK%"=="1" (
    echo Local gateway : Reachable
) else (
    echo Local gateway : Not reachable / not detected
)
if "%EXT_OK%"=="1" (
    echo External host : Reachable (1.1.1.1)
) else (
    echo External host : Not reachable
)
echo.
echo Notes:
echo - This test uses ping (ICMP). Some networks block ping even
echo   when web browsing still works.
echo - No download speed (Mbps) is claimed or measured here.
echo - Full details are in the text report.
echo.
echo Report saved to:
echo   %REPORT%
echo.

:FINISH
echo Opening Reports folder...
start "" explorer "%REPORTS%"
timeout /t 1 >nul
if exist "%REPORT%" start notepad "%REPORT%"

echo.
echo Press any key to exit...
pause >nul
exit /b 0
