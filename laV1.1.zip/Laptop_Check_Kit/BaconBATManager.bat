@echo off
setlocal EnableDelayedExpansion
title Bacon BAT Manager
color 0B

set "ROOT=%~dp0"
if "%ROOT:~-1%"=="\" set "ROOT=%ROOT:~0,-1%"
set "SCRIPTS=%ROOT%\Scripts"
set "PSFILE=powershell.exe -NoProfile -ExecutionPolicy Bypass -File"

if not exist "%ROOT%\Bin"   mkdir "%ROOT%\Bin"   >nul 2>&1
if not exist "%ROOT%\Data"  mkdir "%ROOT%\Data"  >nul 2>&1
if not exist "%ROOT%\Logs"  mkdir "%ROOT%\Logs"  >nul 2>&1

if not exist "%SCRIPTS%\Common.ps1" (
    echo [ERROR] Required files missing. Please re-extract the complete ZIP.
    pause
    exit /b 1
)

:MENU
cls
echo ============================================================
echo          BACON BAT MANAGER
echo ============================================================
echo.
echo   Project folder:
echo   %ROOT%
echo.
echo   1. Scan for BAT Files
echo   2. Move Selected Files to Bin
echo   3. Open Bin / Restore / Delete
echo   4. Run Expired Cleanup Now
echo   5. Enable / Disable Automatic Cleanup
echo   6. View Cleanup Log
echo   7. Refresh Status
echo   8. Resync Bin
echo   9. Exit
echo.
echo ============================================================
set /p "OPT=Enter option [1-9]: "

if "%OPT%"=="1" goto :SCAN
if "%OPT%"=="2" goto :MOVE
if "%OPT%"=="3" goto :BIN
if "%OPT%"=="4" goto :CLEANNOW
if "%OPT%"=="5" goto :BACKGROUND
if "%OPT%"=="6" goto :VIEWLOG
if "%OPT%"=="7" goto :STATUS
if "%OPT%"=="8" goto :RESYNC
if "%OPT%"=="9" goto :EXIT
echo Invalid option.
timeout /t 1 >nul
goto :MENU

:SCAN
cls
echo Running scan...
echo.
%PSFILE% "%SCRIPTS%\ScanBats.ps1"
echo.
pause
goto :MENU

:MOVE
cls
echo ============================================================
echo   MOVE FILES TO BIN
echo ============================================================
echo.
%PSFILE% "%SCRIPTS%\ScanBats.ps1" -Quiet > "%TEMP%\bacon_scan.json" 2>nul
%PSFILE% "%SCRIPTS%\ScanBats.ps1"
echo.
set /p "SEL=Enter numbers (space separated) or ALL or CANCEL: "
if /i "%SEL%"=="CANCEL" goto :MENU
if /i "%SEL%"=="" goto :MENU

echo.
echo Type YES to move the selected file(s) to Bin (24-hour recovery).
set /p "CONF= "
if /i not "%CONF%"=="YES" (
    echo Cancelled.
    pause
    goto :MENU
)

echo.
echo Moving files...
echo.
%PSFILE% "%SCRIPTS%\SelectAndMove.ps1" -ScanJsonFile "%TEMP%\bacon_scan.json" -Selection "%SEL%" -ExpireHours 24
echo.
pause
goto :MENU

:BIN
cls
echo ============================================================
echo   BIN / RECOVERY
echo ============================================================
echo.
%PSFILE% "%SCRIPTS%\ListBin.ps1" -Quiet > "%TEMP%\bacon_bin.json" 2>nul
%PSFILE% "%SCRIPTS%\ListBin.ps1"
echo.
echo Options:
echo   R  = Restore a file   (then type its NUMBER, e.g. 1)
echo   D  = Delete a file permanently (then type its NUMBER)
echo   E  = Empty entire Bin (permanent)
echo   B  = Back to main menu
echo.
set /p "BINOPT=Choice [R/D/E/B]: "

if /i "%BINOPT%"=="B" goto :MENU
if /i "%BINOPT%"=="" goto :MENU

if /i "%BINOPT%"=="E" (
    echo.
    echo WARNING: This permanently deletes EVERY file in the Bin.
    echo Type YES to confirm.
    set /p "ECONF= "
    if /i "!ECONF!"=="YES" (
        %PSFILE% "%SCRIPTS%\PermanentDelete.ps1" -All
    ) else (
        echo Cancelled.
    )
    pause
    goto :BIN
)

if /i "%BINOPT%"=="R" (
    echo.
    echo Type the NUMBER shown in the list above (example: 1)
    set /p "RSEL=Number(s) to restore: "
    if "!RSEL!"=="" (
        echo No number entered.
        pause
        goto :BIN
    )
    %PSFILE% "%SCRIPTS%\SelectAndAction.ps1" -Action Restore -BinJsonFile "%TEMP%\bacon_bin.json" -Selection "!RSEL!"
    pause
    goto :BIN
)

if /i "%BINOPT%"=="D" (
    echo.
    echo Type the NUMBER shown in the list above (example: 1)
    set /p "DSEL=Number(s) to delete: "
    if "!DSEL!"=="" (
        echo No number entered.
        pause
        goto :BIN
    )
    echo Type YES to confirm permanent deletion.
    set /p "DCONF= "
    if /i "!DCONF!"=="YES" (
        %PSFILE% "%SCRIPTS%\SelectAndAction.ps1" -Action Delete -BinJsonFile "%TEMP%\bacon_bin.json" -Selection "!DSEL!"
    ) else (
        echo Cancelled.
    )
    pause
    goto :BIN
)

echo Unknown choice. Use R, D, E or B.
timeout /t 2 >nul
goto :BIN

:CLEANNOW
cls
echo Running expired-item cleanup...
echo.
%PSFILE% "%SCRIPTS%\CleanupExpired.ps1"
echo.
pause
goto :MENU

:BACKGROUND
cls
echo ============================================================
echo   AUTOMATIC CLEANUP
echo ============================================================
echo.
echo   1. Show status
echo   2. Enable automatic cleanup
echo   3. Disable automatic cleanup
echo   4. Back
echo.
set /p "BG=Choice: "
if "%BG%"=="1" %PSFILE% "%SCRIPTS%\SetupBackground.ps1" -Action Status
if "%BG%"=="2" %PSFILE% "%SCRIPTS%\SetupBackground.ps1" -Action Enable
if "%BG%"=="3" %PSFILE% "%SCRIPTS%\SetupBackground.ps1" -Action Disable
if "%BG%"=="4" goto :MENU
echo.
pause
goto :BACKGROUND

:VIEWLOG
cls
echo Recent log entries:
echo.
if exist "%ROOT%\Logs" (
    for /f "delims=" %%F in ('dir /b /o-d "%ROOT%\Logs\*.log" 2^>nul') do (
        echo ---- %%F ----
        type "%ROOT%\Logs\%%F"
        echo.
        goto :LOGDONE
    )
    echo No log files yet.
) else (
    echo Logs folder not found.
)
:LOGDONE
echo.
pause
goto :MENU

:STATUS
cls
echo ============================================================
echo   STATUS
echo ============================================================
echo.
echo Project : %ROOT%
echo.
%PSFILE% "%SCRIPTS%\ListBin.ps1" -Quiet >nul 2>&1
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "& { . '%SCRIPTS%\Common.ps1'; Ensure-Folders; $items = Get-BinItems; $now = Get-Date; $pending=0; $expired=0; foreach ($e in $items) { try { $exp=[datetime]::Parse($e.ExpireTime); if ($now -ge $exp) { $expired++ } else { $pending++ } } catch { $pending++ } }; Write-Host ('Files in Bin          : {0}' -f $items.Count); Write-Host ('  Still recoverable  : {0}' -f $pending); Write-Host ('  Expired            : {0}' -f $expired); Write-Host ''; $t = Get-ScheduledTask -TaskName 'BaconBATManager_Cleanup' -ErrorAction SilentlyContinue; if ($t) { Write-Host ('Automatic cleanup    : ' + $t.State) } else { Write-Host 'Automatic cleanup    : Not turned on' } }"
echo.
pause
goto :MENU

:RESYNC
cls
echo Running Bin resync...
echo.
%PSFILE% "%SCRIPTS%\ResyncBin.ps1"
echo.
pause
goto :MENU

:EXIT
echo.
echo Exiting Bacon BAT Manager.
timeout /t 1 >nul
exit /b 0
