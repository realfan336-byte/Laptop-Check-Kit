@echo off
setlocal EnableDelayedExpansion
title Laptop Check Kit - Battery Check

call "%~dp0Support\common.bat"
if errorlevel 1 (
    echo [ERROR] Cannot load common support file.
    pause
    exit /b 1
)

call :Timestamp
set "REPORT=%REPORTS_DIR%\Battery_Test_%TIMESTAMP%.txt"
set "HTML_REPORT=%REPORTS_DIR%\battery-report_%TIMESTAMP%.html"

echo ============================================================
echo   BATTERY CHECK
echo ============================================================
echo.
echo Collecting battery information using built-in Windows tools.
echo If no battery is present or the battery is not detected,
echo the script will report that clearly (no invented data).
echo.

(
    echo Laptop Check Kit - Battery Report
    echo Generated: %date% %time%
    echo ============================================================
    echo.
) > "%REPORT%"

echo [1/3] Battery presence and status (WMIC)...
echo ----- WMIC Battery ----- >> "%REPORT%"
wmic path Win32_Battery get Availability,BatteryStatus,EstimatedChargeRemaining,EstimatedRunTime,Status,Caption /format:list >> "%REPORT%" 2>&1
if errorlevel 1 (
    echo [INFO] WMIC battery query returned an error or no battery found.
    echo [INFO] WMIC query failed or no battery. >> "%REPORT%"
)

echo.
echo Current battery summary (if any):
wmic path Win32_Battery get EstimatedChargeRemaining,BatteryStatus,Status 2>nul
if errorlevel 1 (
    echo No battery information returned by WMIC.
)

echo.
echo [2/3] Power configuration...
echo ----- Power Configuration ----- >> "%REPORT%"
powercfg /batteryreport /output "%HTML_REPORT%" 2>>"%REPORT%"
if errorlevel 1 (
    echo [INFO] powercfg /batteryreport failed or is not supported.
    echo This is common on desktop PCs or when no battery is present.
    echo [INFO] powercfg /batteryreport failed. >> "%REPORT%"
    set "HAS_HTML=0"
) else (
    echo Battery HTML report generated.
    echo Location: %HTML_REPORT%
    echo HTML report created: %HTML_REPORT% >> "%REPORT%"
    set "HAS_HTML=1"
)

echo.
echo [3/3] Additional power info...
echo ----- powercfg /energy (not run - lengthy) ----- >> "%REPORT%"
echo Note: Full energy report (powercfg /energy) takes ~60 seconds
echo and was not run automatically. You can run it manually if needed.
echo. >> "%REPORT%"
powercfg /list >> "%REPORT%" 2>&1

echo.
echo ============================================================
echo   Battery check finished.
echo   Text report: %REPORT%
if "%HAS_HTML%"=="1" (
    echo   HTML report: %HTML_REPORT%
    echo.
    echo Opening HTML report...
    start "" "%HTML_REPORT%"
)
echo ============================================================
echo.
echo If no battery data appears, the system likely has no working
echo battery (desktop, battery removed, or hardware fault).
echo.
start notepad "%REPORT%"
call :PauseAndReturn
exit /b 0
