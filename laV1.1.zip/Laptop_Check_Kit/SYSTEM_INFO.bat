@echo off
setlocal EnableDelayedExpansion
title Laptop Check Kit - System Information

call "%~dp0Support\common.bat"
if errorlevel 1 (
    echo [ERROR] Cannot load common support file.
    pause
    exit /b 1
)

call :Timestamp
set "REPORT=%REPORTS_DIR%\SystemInfo_%TIMESTAMP%.txt"

echo ============================================================
echo   SYSTEM INFORMATION
echo ============================================================
echo.
echo Collecting genuine Windows system information...
echo Report will be saved to:
echo   %REPORT%
echo.

(
    echo Laptop Check Kit - System Information Report
    echo Generated: %date% %time%
    echo ============================================================
    echo.
) > "%REPORT%"

echo [1/6] Basic system info...
echo ----- Basic System ----- >> "%REPORT%"
systeminfo >> "%REPORT%" 2>&1
if errorlevel 1 (
    echo [WARN] systeminfo returned an error. Continuing with other tools.
    echo [WARN] systeminfo error >> "%REPORT%"
)
echo. >> "%REPORT%"

echo [2/6] Processor information...
echo ----- Processor ----- >> "%REPORT%"
wmic cpu get Name,NumberOfCores,NumberOfLogicalProcessors,MaxClockSpeed,Architecture /format:list >> "%REPORT%" 2>&1
echo. >> "%REPORT%"

echo [3/6] Memory information...
echo ----- Memory ----- >> "%REPORT%"
wmic memorychip get Capacity,Speed,Manufacturer,PartNumber /format:list >> "%REPORT%" 2>&1
wmic OS get TotalVisibleMemorySize,FreePhysicalMemory /format:list >> "%REPORT%" 2>&1
echo. >> "%REPORT%"

echo [4/6] Windows version and architecture...
echo ----- Windows Version ----- >> "%REPORT%"
ver >> "%REPORT%" 2>&1
echo. >> "%REPORT%"
wmic os get Caption,Version,OSArchitecture,BuildNumber /format:list >> "%REPORT%" 2>&1
echo. >> "%REPORT%"

echo [5/6] Graphics information...
echo ----- Graphics ----- >> "%REPORT%"
wmic path win32_VideoController get Name,AdapterRAM,DriverVersion /format:list >> "%REPORT%" 2>&1
echo. >> "%REPORT%"

echo [6/6] Disk drives...
echo ----- Logical Disks ----- >> "%REPORT%"
wmic logicaldisk get DeviceID,FileSystem,Size,FreeSpace,VolumeName /format:list >> "%REPORT%" 2>&1
echo. >> "%REPORT%"
echo ----- Physical Disks ----- >> "%REPORT%"
wmic diskdrive get Model,Size,Status,InterfaceType /format:list >> "%REPORT%" 2>&1

echo.
echo ============================================================
echo   Collection complete.
echo   Report saved to: %REPORT%
echo ============================================================
echo.
echo Opening report in Notepad...
start notepad "%REPORT%"
call :PauseAndReturn
exit /b 0
