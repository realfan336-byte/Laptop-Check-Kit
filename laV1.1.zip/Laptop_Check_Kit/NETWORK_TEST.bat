@echo off
setlocal EnableDelayedExpansion
title Laptop Check Kit - Network Check

call "%~dp0Support\common.bat"
if errorlevel 1 (
    echo [ERROR] Cannot load common support file.
    pause
    exit /b 1
)

call :Timestamp
set "REPORT=%REPORTS_DIR%\Network_Test_%TIMESTAMP%.txt"

echo ============================================================
echo   NETWORK CHECK
echo ============================================================
echo.
echo This checks:
echo   - Network adapter status
echo   - IP configuration
echo   - Default gateway reachability
echo   - DNS configuration
echo   - Internet connectivity (to a reliable public host)
echo.
echo It does NOT display Wi-Fi passwords or saved credentials.
echo.

(
    echo Laptop Check Kit - Network Report
    echo Generated: %date% %time%
    echo ============================================================
    echo.
) > "%REPORT%"

echo [1/5] Adapter status...
echo ----- Adapters ----- >> "%REPORT%"
ipconfig /all >> "%REPORT%" 2>&1
echo. >> "%REPORT%"

echo.
echo Current adapters (summary):
ipconfig

echo.
echo [2/5] Default gateway...
echo ----- Gateway ----- >> "%REPORT%"
set "GATEWAY="
for /f "tokens=2 delims=:" %%g in ('ipconfig ^| findstr /i /c:"Default Gateway"') do (
    set "TEMP=%%g"
    set "TEMP=!TEMP: =!"
    if not "!TEMP!"=="" if not "!TEMP!"=="0.0.0.0" (
        set "GATEWAY=!TEMP!"
    )
)
if defined GATEWAY (
    echo Detected gateway: %GATEWAY%
    echo Gateway: %GATEWAY% >> "%REPORT%"
    echo Pinging gateway...
    ping -n 2 %GATEWAY% >> "%REPORT%" 2>&1
    if errorlevel 1 (
        echo [WARN] Gateway did not respond to ping.
        echo [WARN] Gateway ping failed. >> "%REPORT%"
    ) else (
        echo Gateway responded.
        echo Gateway responded. >> "%REPORT%"
    )
) else (
    echo No default gateway detected.
    echo No default gateway detected. >> "%REPORT%"
)
echo. >> "%REPORT%"

echo.
echo [3/5] DNS configuration...
echo ----- DNS ----- >> "%REPORT%"
ipconfig /displaydns >nul 2>&1
nslookup localhost >> "%REPORT%" 2>&1
echo. >> "%REPORT%"

echo.
echo [4/5] Local name resolution test...
echo ----- Local connectivity ----- >> "%REPORT%"
ping -n 1 127.0.0.1 >> "%REPORT%" 2>&1
if errorlevel 1 (
    echo [ERROR] Localhost ping failed - unusual.
) else (
    echo Localhost OK.
)

echo.
echo [5/5] Internet connectivity (Cloudflare 1.1.1.1)...
echo ----- Internet ----- >> "%REPORT%"
echo Testing reachability of 1.1.1.1 (Cloudflare DNS)...
ping -n 3 1.1.1.1 >> "%REPORT%" 2>&1
if errorlevel 1 (
    echo [WARN] Could not reach 1.1.1.1
    echo This may mean no internet, firewall block, or network issue.
    echo [WARN] 1.1.1.1 unreachable. >> "%REPORT%"
    set "NET_OK=0"
) else (
    echo Internet host responded.
    echo 1.1.1.1 responded. >> "%REPORT%"
    set "NET_OK=1"
)

echo.
echo Optional: testing DNS name resolution (www.microsoft.com)...
nslookup www.microsoft.com >> "%REPORT%" 2>&1
if errorlevel 1 (
    echo [WARN] DNS lookup of www.microsoft.com failed.
    echo [WARN] DNS lookup failed. >> "%REPORT%"
) else (
    echo DNS lookup succeeded.
)

echo.
echo ============================================================
echo   Network check finished.
echo   Report: %REPORT%
echo ============================================================
echo.
if "%NET_OK%"=="1" (
    echo Summary: Internet host reachable.
) else (
    echo Summary: Internet host NOT reachable from this test.
    echo Check cables, Wi-Fi, router, or ISP if you expected connectivity.
)
echo.
echo Note: Successful pings do not guarantee perfect network health.
echo.
start notepad "%REPORT%"
call :PauseAndReturn
exit /b 0
