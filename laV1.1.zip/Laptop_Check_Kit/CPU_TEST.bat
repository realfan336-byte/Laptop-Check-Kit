@echo off
setlocal EnableDelayedExpansion
title Laptop Check Kit - CPU Workload Test

call "%~dp0Support\common.bat"
if errorlevel 1 (
    echo [ERROR] Cannot load common support file.
    pause
    exit /b 1
)

call :Timestamp
set "REPORT=%REPORTS_DIR%\CPU_Test_%TIMESTAMP%.txt"

echo ============================================================
echo   CPU WORKLOAD TEST
echo ============================================================
echo.
echo This runs a genuine, bounded CPU workload using PowerShell.
echo It does NOT prove the CPU is healthy. Completing the test
echo only means the system stayed responsive for the chosen time.
echo.
echo WARNING: Stop the test immediately if the laptop becomes
echo excessively hot, the fan is extremely loud, or the system
echo becomes unstable.
echo.
echo Choose test duration:
echo   1. 15 seconds  (quick)
echo   2. 30 seconds  (default)
echo   3. 60 seconds
echo   4. Cancel
echo.
set /p "CHOICE=Enter choice [1-4, default 2]: "
if "%CHOICE%"=="" set "CHOICE=2"
if "%CHOICE%"=="4" (
    echo Cancelled by user.
    call :PauseAndReturn
    exit /b 0
)
if "%CHOICE%"=="1" set "SECONDS=15"
if "%CHOICE%"=="2" set "SECONDS=30"
if "%CHOICE%"=="3" set "SECONDS=60"
if not defined SECONDS (
    echo Invalid choice. Using default 30 seconds.
    set "SECONDS=30"
)

echo.
echo Starting %SECONDS%-second CPU workload...
echo Press Ctrl+C if you need to stop early.
echo.

(
    echo Laptop Check Kit - CPU Workload Report
    echo Generated: %date% %time%
    echo Duration requested: %SECONDS% seconds
    echo ============================================================
    echo.
) > "%REPORT%"

powershell -NoProfile -Command ^
    "$ErrorActionPreference='Stop'; " ^
    "$sw = [System.Diagnostics.Stopwatch]::StartNew(); " ^
    "$end = (Get-Date).AddSeconds(%SECONDS%); " ^
    "$cores = [Environment]::ProcessorCount; " ^
    "Write-Host \"Using $cores logical processor(s)\"; " ^
    "Write-Host \"Workload running...\"; " ^
    "try { " ^
    "  $jobs = 1..$cores | ForEach-Object { " ^
    "    Start-Job -ScriptBlock { " ^
    "      $r = 0; " ^
    "      while ((Get-Date) -lt $using:end) { $r += [Math]::Sqrt([Math]::Pow(123456.789, 2) + 987654.321) } " ^
    "      $r " ^
    "    } " ^
    "  }; " ^
    "  $jobs | Wait-Job | Out-Null; " ^
    "  $jobs | Remove-Job -Force; " ^
    "  $sw.Stop(); " ^
    "  Write-Host \"Elapsed: $([math]::Round($sw.Elapsed.TotalSeconds,1)) seconds\"; " ^
    "  Write-Host \"Workload finished without script-level error.\"; " ^
    "} catch { " ^
    "  Write-Host \"ERROR during workload: $_\"; " ^
    "  exit 1 " ^
    "}"

set "PS_ERR=%ERRORLEVEL%"
if %PS_ERR% NEQ 0 (
    echo [ERROR] PowerShell workload reported an error. Code: %PS_ERR%
    echo [ERROR] PowerShell error code %PS_ERR% >> "%REPORT%"
) else (
    echo Workload completed.
    echo Workload completed without PowerShell error. >> "%REPORT%"
)

echo.
echo IMPORTANT:
echo - Completing this test does NOT prove the CPU is healthy.
echo - It only shows the system remained responsive under load
echo   for the selected duration.
echo - If the laptop overheated or became unstable, stop using
echo   heavy workloads and consider professional diagnosis.
echo.
echo Report saved to: %REPORT%
echo.
call :PauseAndReturn
exit /b 0
