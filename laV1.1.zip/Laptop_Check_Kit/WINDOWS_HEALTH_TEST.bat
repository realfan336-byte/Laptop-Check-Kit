@echo off
setlocal EnableDelayedExpansion
title Laptop Check Kit - Windows Health Checks

call "%~dp0Support\common.bat"
if errorlevel 1 (
    echo [ERROR] Cannot load common support file.
    pause
    exit /b 1
)

call :Timestamp
set "REPORT=%REPORTS_DIR%\Windows_Health_%TIMESTAMP%.txt"

echo ============================================================
echo   WINDOWS HEALTH CHECKS
echo ============================================================
echo.
echo Available genuine checks:
echo   1. sfc /verifyonly   - Verify system files (no repair)
echo   2. DISM health scan  - Check component store health
echo   3. Both (recommended order)
echo   4. Cancel
echo.
echo IMPORTANT:
echo - These checks can take a long time (10-30+ minutes).
echo - Administrator permission is strongly recommended.
echo - This script does NOT run automatic repairs (no /scannow,
echo   no /RestoreHealth by default).
echo - A clean result does not guarantee the system is perfect.
echo.

net session >nul 2>&1
if errorlevel 1 (
    echo [WARN] You are NOT running as Administrator.
    echo Some checks may fail or give incomplete results.
    echo Right-click the script and choose "Run as administrator"
    echo for best results.
    echo.
) else (
    echo Running with Administrator privileges.
    echo.
)

set /p "CHOICE=Enter choice [1-4, default 3]: "
if "%CHOICE%"=="" set "CHOICE=3"
if "%CHOICE%"=="4" (
    echo Cancelled.
    call :PauseAndReturn
    exit /b 0
)

(
    echo Laptop Check Kit - Windows Health Report
    echo Generated: %date% %time%
    echo ============================================================
    echo.
) > "%REPORT%"

if "%CHOICE%"=="1" goto :SFC
if "%CHOICE%"=="2" goto :DISM
if "%CHOICE%"=="3" goto :BOTH
echo Invalid choice. Running both.
goto :BOTH

:SFC
echo.
echo Running: sfc /verifyonly
echo This only verifies; it does not repair files.
echo Please wait...
echo ----- sfc /verifyonly ----- >> "%REPORT%"
sfc /verifyonly >> "%REPORT%" 2>&1
set "SFC_ERR=%ERRORLEVEL%"
echo sfc exit code: %SFC_ERR% >> "%REPORT%"
if %SFC_ERR% EQU 0 (
    echo sfc completed with code 0.
) else (
    echo [WARN] sfc returned code %SFC_ERR%. See report for details.
)
goto :END

:DISM
echo.
echo Running: DISM /Online /Cleanup-Image /CheckHealth
echo (Quick check of component store)
echo ----- DISM CheckHealth ----- >> "%REPORT%"
DISM /Online /Cleanup-Image /CheckHealth >> "%REPORT%" 2>&1
set "DISM_ERR=%ERRORLEVEL%"
echo DISM CheckHealth exit code: %DISM_ERR% >> "%REPORT%"
if %DISM_ERR% EQU 0 (
    echo DISM CheckHealth completed with code 0.
) else (
    echo [WARN] DISM returned code %DISM_ERR%. See report.
)
echo.
echo Optional deeper scan (takes longer): DISM /ScanHealth
set /p "DEEPER=Run ScanHealth as well? (Y/N) [N]: "
if /i "%DEEPER%"=="Y" (
    echo Running DISM /ScanHealth (this can take a while)...
    echo ----- DISM ScanHealth ----- >> "%REPORT%"
    DISM /Online /Cleanup-Image /ScanHealth >> "%REPORT%" 2>&1
    echo DISM ScanHealth exit code: %ERRORLEVEL% >> "%REPORT%"
)
goto :END

:BOTH
echo.
echo Step 1 of 2: sfc /verifyonly
echo ----- sfc /verifyonly ----- >> "%REPORT%"
sfc /verifyonly >> "%REPORT%" 2>&1
echo sfc exit code: %ERRORLEVEL% >> "%REPORT%"
echo.
echo Step 2 of 2: DISM /CheckHealth
echo ----- DISM CheckHealth ----- >> "%REPORT%"
DISM /Online /Cleanup-Image /CheckHealth >> "%REPORT%" 2>&1
echo DISM exit code: %ERRORLEVEL% >> "%REPORT%"
goto :END

:END
echo.
echo ============================================================
echo   Health checks finished.
echo   Report: %REPORT%
echo ============================================================
echo.
echo Notes:
echo - These tools report what they find; they do not invent results.
echo - If problems are reported, further action (run as admin,
echo   sfc /scannow, DISM /RestoreHealth) may be needed - but those
echo   are repair commands and are NOT run automatically by this kit.
echo - A clean scan does not prove the system is free of all issues.
echo.
start notepad "%REPORT%"
call :PauseAndReturn
exit /b 0
