@echo off
setlocal EnableDelayedExpansion
title Laptop Check Kit - Windows Memory Diagnostic

call "%~dp0Support\common.bat"
if errorlevel 1 (
    echo [ERROR] Cannot load common support file.
    pause
    exit /b 1
)

call :Timestamp
set "REPORT=%REPORTS_DIR%\RAM_Test_Info_%TIMESTAMP%.txt"

echo ============================================================
echo   WINDOWS MEMORY DIAGNOSTIC
echo ============================================================
echo.
echo This launches the genuine Microsoft Windows Memory Diagnostic
echo tool (mdsched.exe). It is NOT a simulated test.
echo.
echo IMPORTANT:
echo - The diagnostic usually requires a restart to run.
echo - After the test finishes and Windows restarts, results are
echo   written to the System event log.
echo - This script does NOT invent or display fake RAM results.
echo - If you do not restart, the diagnostic has not run.
echo.
echo How to view results later:
echo   1. Open Event Viewer (eventvwr.msc)
echo   2. Go to: Windows Logs -^> System
echo   3. Look for source "MemoryDiagnostics-Results"
echo   4. Or run: wevtutil qe System /q:"*[System[Provider[@Name='MemoryDiagnostics-Results']]]" /f:text /c:5
echo.
echo Do you want to open Windows Memory Diagnostic now?
echo   Y = Yes, open mdsched.exe (you will be asked about restart)
echo   N = No, just save this explanation and return
echo.
set /p "CHOICE=Enter Y or N [default N]: "
if /i not "%CHOICE%"=="Y" (
    echo.
    echo Cancelled. No diagnostic was started.
    (
        echo Laptop Check Kit - RAM Test Information
        echo Generated: %date% %time%
        echo User chose not to launch Windows Memory Diagnostic.
        echo No memory test was performed by this script.
    ) > "%REPORT%"
    echo Explanation saved to: %REPORT%
    call :PauseAndReturn
    exit /b 0
)

echo.
echo Launching mdsched.exe...
echo If User Account Control appears, approve it.
echo You will be offered to restart now or later.
echo.

start "" mdsched.exe
if errorlevel 1 (
    echo [ERROR] Could not start mdsched.exe
    echo Possible reasons: tool missing, blocked, or path issue.
    (
        echo Laptop Check Kit - RAM Test Information
        echo Generated: %date% %time%
        echo ERROR: Failed to start mdsched.exe
        echo No memory test was performed.
    ) > "%REPORT%"
) else (
    echo mdsched.exe was started.
    echo Remember: the actual test runs after a restart.
    (
        echo Laptop Check Kit - RAM Test Information
        echo Generated: %date% %time%
        echo mdsched.exe was launched successfully.
        echo The memory diagnostic itself runs after Windows restarts.
        echo This script does not read or invent test results.
        echo.
        echo To view results after reboot:
        echo   Event Viewer -^> Windows Logs -^> System
        echo   Source: MemoryDiagnostics-Results
    ) > "%REPORT%"
)

echo.
echo Info saved to: %REPORT%
call :PauseAndReturn
exit /b 0
