@echo off
setlocal EnableDelayedExpansion
title Laptop Check Kit - Main Menu

call "%~dp0Support\common.bat"
if errorlevel 1 (
    echo [ERROR] Cannot load Support\common.bat
    echo Make sure the Support folder and common.bat exist.
    pause
    exit /b 1
)

:MENU
cls
echo ============================================================
echo          LAPTOP CHECK KIT - MAIN MENU
echo ============================================================
echo.
echo   1.  Run system information
echo   2.  Run CPU workload test
echo   3.  Open Windows RAM diagnostic
echo   4.  Run disk checks
echo   5.  Run battery check
echo   6.  Run network check
echo   7.  Run Windows health checks
echo   8.  Review recent system errors
echo   9.  Check kit files and dependencies
echo  10.  Run all suitable non-rebooting checks
echo  11.  Open the Reports folder
echo  12.  Exit
echo.
echo   (Also available: CRASH_DEMO.bat - simulation only)
echo ============================================================
echo.
set /p "OPT=Enter option [1-12]: "

if "%OPT%"=="1"  goto :RUN_SYS
if "%OPT%"=="2"  goto :RUN_CPU
if "%OPT%"=="3"  goto :RUN_RAM
if "%OPT%"=="4"  goto :RUN_DISK
if "%OPT%"=="5"  goto :RUN_BATT
if "%OPT%"=="6"  goto :RUN_NET
if "%OPT%"=="7"  goto :RUN_HEALTH
if "%OPT%"=="8"  goto :RUN_EVENT
if "%OPT%"=="9"  goto :RUN_CHECK
if "%OPT%"=="10" goto :RUN_ALL
if "%OPT%"=="11" goto :OPEN_REPORTS
if "%OPT%"=="12" goto :EXIT
echo Invalid option.
pause
goto :MENU

:RUN_SYS
call "%~dp0SYSTEM_INFO.bat"
goto :MENU

:RUN_CPU
call "%~dp0CPU_TEST.bat"
goto :MENU

:RUN_RAM
call "%~dp0RAM_TEST.bat"
goto :MENU

:RUN_DISK
call "%~dp0DISK_TEST.bat"
goto :MENU

:RUN_BATT
call "%~dp0BATTERY_TEST.bat"
goto :MENU

:RUN_NET
call "%~dp0NETWORK_TEST.bat"
goto :MENU

:RUN_HEALTH
call "%~dp0WINDOWS_HEALTH_TEST.bat"
goto :MENU

:RUN_EVENT
call "%~dp0EVENT_LOG_TEST.bat"
goto :MENU

:RUN_CHECK
call "%~dp0CHECK_FILES.bat"
goto :MENU

:OPEN_REPORTS
if not exist "%REPORTS_DIR%" mkdir "%REPORTS_DIR%"
explorer "%REPORTS_DIR%"
goto :MENU

:RUN_ALL
cls
echo ============================================================
echo   RUN ALL SUITABLE NON-REBOOTING CHECKS
echo ============================================================
echo.
echo This will run:
echo   - System information
echo   - CPU workload (short default)
echo   - Disk checks (read-only)
echo   - Battery check
echo   - Network check
echo   - Event log review
echo   - Kit file check
echo.
echo SKIPPED (require interaction or reboot):
echo   - Windows Memory Diagnostic (needs restart)
echo   - Full Windows health repairs
echo.
echo Individual tests may still ask for confirmation.
echo Continue? (Y/N)
set /p "GO= "
if /i not "%GO%"=="Y" goto :MENU

set "FAILS=0"

echo.
echo ===== [1/7] System Information =====
call "%~dp0SYSTEM_INFO.bat"
if errorlevel 1 set /a FAILS+=1

echo.
echo ===== [2/7] CPU Workload (will use default duration) =====
echo Note: You will still be prompted for duration inside the test.
call "%~dp0CPU_TEST.bat"
if errorlevel 1 set /a FAILS+=1

echo.
echo ===== [3/7] Disk Checks =====
call "%~dp0DISK_TEST.bat"
if errorlevel 1 set /a FAILS+=1

echo.
echo ===== [4/7] Battery Check =====
call "%~dp0BATTERY_TEST.bat"
if errorlevel 1 set /a FAILS+=1

echo.
echo ===== [5/7] Network Check =====
call "%~dp0NETWORK_TEST.bat"
if errorlevel 1 set /a FAILS+=1

echo.
echo ===== [6/7] Event Log Review =====
call "%~dp0EVENT_LOG_TEST.bat"
if errorlevel 1 set /a FAILS+=1

echo.
echo ===== [7/7] Kit File Check =====
call "%~dp0CHECK_FILES.bat"
if errorlevel 1 set /a FAILS+=1

echo.
echo ============================================================
echo   ALL NON-REBOOTING CHECKS FINISHED
echo   Recorded potential issues: %FAILS%
echo   Review files in the Reports folder for details.
echo ============================================================
echo.
echo RAM diagnostic and full health repairs were NOT run because
echo they require reboot or explicit repair decisions.
echo.
pause
goto :MENU

:EXIT
echo.
echo Exiting Laptop Check Kit. Goodbye.
timeout /t 2 >nul
exit /b 0
