@echo off
setlocal EnableDelayedExpansion
title Bacon Windows Tools - Quick Boost
color 0B

REM ============================================================
REM  Quick_Boost.bat
REM  Safe system overview + optional user temp cleanup
REM  Paths are relative to this script (%~dp0)
REM ============================================================

set "SCRIPT_DIR=%~dp0"
if "%SCRIPT_DIR:~-1%"=="\" set "SCRIPT_DIR=%SCRIPT_DIR:~0,-1%"

echo ============================================================
echo   QUICK BOOST - System Overview + Safe Temp Cleanup
echo ============================================================
echo.
echo Script location: %SCRIPT_DIR%
echo.

REM --- Detect Windows version ---
echo [1] Detecting Windows version...
ver
echo.
for /f "tokens=4-5 delims=. " %%i in ('ver') do set "WINVER=%%i.%%j"
echo Detected version string: %WINVER%
echo.

REM --- CPU and Memory usage (genuine built-in tools) ---
echo [2] Current CPU and Memory usage...
echo.
echo ----- CPU Load (approximate via wmic) -----
wmic cpu get LoadPercentage /value 2>nul
if errorlevel 1 (
    echo [WARN] Could not read CPU load percentage.
)
echo.
echo ----- Memory -----
wmic OS get TotalVisibleMemorySize,FreePhysicalMemory /format:list 2>nul
if errorlevel 1 (
    echo [WARN] Could not read memory information.
)
echo.
echo Note: These are snapshot values only. This tool does not
echo claim to have "boosted" CPU or RAM.
echo.

REM --- Drive free space ---
echo [3] Available space on logical drives...
echo.
wmic logicaldisk get DeviceID,FileSystem,Size,FreeSpace /format:table 2>nul
if errorlevel 1 (
    echo [WARN] Could not list drive space.
)
echo.

REM --- Safe temp cleanup offer ---
echo ============================================================
echo   SAFE TEMPORARY FILE CLEANUP (optional)
echo ============================================================
echo.
echo This can safely remove temporary files belonging to the
echo CURRENT USER only (from %%TEMP%% and %%LOCALAPPDATA%%\Temp).
echo.
echo It will NEVER delete:
echo   - Downloads folder
echo   - Desktop files
echo   - Personal Documents
echo   - Windows system files
echo.
echo Files that are in use or inaccessible will be skipped.
echo.
set /p "DO_CLEAN=Do you want to clean user temporary files? (Y/N) [N]: "
if /i not "%DO_CLEAN%"=="Y" (
    echo.
    echo Cleanup skipped. No files were deleted.
    goto :END
)

echo.
echo You chose to clean temporary files.
echo This will only affect the current user's temp folders.
echo.
set /p "CONFIRM=Type YES to confirm deletion of temp files: "
if /i not "%CONFIRM%"=="YES" (
    echo.
    echo Confirmation not received. No files were deleted.
    goto :END
)

echo.
echo Cleaning user temporary files...
echo (In-use or locked files will be skipped automatically)
echo.

set "CLEANED=0"
set "SKIPPED=0"

REM User TEMP
if exist "%TEMP%" (
    echo Cleaning: %TEMP%
    for /f "delims=" %%F in ('dir /a-d /b "%TEMP%\*" 2^>nul') do (
        del /q /f "%TEMP%\%%F" >nul 2>&1
        if errorlevel 1 (
            set /a SKIPPED+=1
        ) else (
            set /a CLEANED+=1
        )
    )
    for /d %%D in ("%TEMP%\*") do (
        rd /s /q "%%D" >nul 2>&1
    )
)

REM LocalAppData Temp
if exist "%LOCALAPPDATA%\Temp" (
    echo Cleaning: %LOCALAPPDATA%\Temp
    for /f "delims=" %%F in ('dir /a-d /b "%LOCALAPPDATA%\Temp\*" 2^>nul') do (
        del /q /f "%LOCALAPPDATA%\Temp\%%F" >nul 2>&1
        if errorlevel 1 (
            set /a SKIPPED+=1
        ) else (
            set /a CLEANED+=1
        )
    )
    for /d %%D in ("%LOCALAPPDATA%\Temp\*") do (
        rd /s /q "%%D" >nul 2>&1
    )
)

echo.
echo Cleanup finished.
echo Approximate files removed: %CLEANED%
echo Items skipped (in use / access denied): %SKIPPED%
echo.
echo IMPORTANT: This does not claim any measurable CPU or RAM boost.
echo Freeing temporary files only recovers disk space.

:END
echo.
echo ============================================================
echo   Finished.
echo ============================================================
echo.
echo Press any key to exit...
pause >nul
exit /b 0
