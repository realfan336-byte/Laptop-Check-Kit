@echo off
setlocal EnableDelayedExpansion
title Laptop Check Kit - Recent System Errors

call "%~dp0Support\common.bat"
if errorlevel 1 (
    echo [ERROR] Cannot load common support file.
    pause
    exit /b 1
)

call :Timestamp
set "REPORT=%REPORTS_DIR%\EventLog_%TIMESTAMP%.txt"

echo ============================================================
echo   RECENT SYSTEM ERRORS AND WARNINGS
echo ============================================================
echo.
echo Reading recent Error and Warning events from the System log
echo using built-in wevtutil. Access may be limited without admin.
echo.

(
    echo Laptop Check Kit - Event Log Report
    echo Generated: %date% %time%
    echo ============================================================
    echo.
) > "%REPORT%"

echo [1/2] Querying System log for recent Errors (last 20)...
echo ----- Recent Errors ----- >> "%REPORT%"
wevtutil qe System /q:"*[System[(Level=1 or Level=2)]]" /f:text /c:20 /rd:true >> "%REPORT%" 2>&1
set "ERR1=%ERRORLEVEL%"
if %ERR1% NEQ 0 (
    echo [WARN] wevtutil errors query returned code %ERR1%.
    echo Possible causes: access denied, log empty, or tool issue.
    echo [WARN] Errors query exit code %ERR1% >> "%REPORT%"
) else (
    echo Errors query completed.
)

echo.
echo [2/2] Querying System log for recent Warnings (last 20)...
echo ----- Recent Warnings ----- >> "%REPORT%"
wevtutil qe System /q:"*[System[(Level=3)]]" /f:text /c:20 /rd:true >> "%REPORT%" 2>&1
set "ERR2=%ERRORLEVEL%"
if %ERR2% NEQ 0 (
    echo [WARN] wevtutil warnings query returned code %ERR2%.
    echo [WARN] Warnings query exit code %ERR2% >> "%REPORT%"
) else (
    echo Warnings query completed.
)

echo.
echo Also capturing last 10 Critical/Error events in short form...
echo ----- Short form (Critical/Error) ----- >> "%REPORT%"
wevtutil qe System /q:"*[System[(Level=1 or Level=2)]]" /f:text /c:10 /rd:true /l:en-US >> "%REPORT%" 2>&1

echo.
echo ============================================================
echo   Event log query finished.
echo   Report: %REPORT%
echo ============================================================
echo.
echo Notes:
echo - "Access is denied" usually means run as Administrator.
echo - An empty result can mean few recent errors (good) or
echo   permission issues.
echo - Review the full messages in the report carefully.
echo.
start notepad "%REPORT%"
call :PauseAndReturn
exit /b 0
