# Common.ps1 - Shared functions for Bacon BAT Manager
$ErrorActionPreference = "Stop"

function Get-ManagerRoot {
    $scriptDir = $PSScriptRoot
    if (-not $scriptDir) { $scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path }
    return (Resolve-Path (Join-Path $scriptDir "..")).Path
}

function Get-BinPath  { Join-Path (Get-ManagerRoot) "Bin" }
function Get-DataPath { Join-Path (Get-ManagerRoot) "Data" }
function Get-LogsPath { Join-Path (Get-ManagerRoot) "Logs" }

function Ensure-Folders {
    foreach ($f in @((Get-BinPath), (Get-DataPath), (Get-LogsPath))) {
        if (-not (Test-Path -LiteralPath $f)) {
            New-Item -ItemType Directory -Path $f -Force | Out-Null
        }
    }
}

function Write-Log {
    param([string]$Message, [string]$Level = "INFO")
    try {
        Ensure-Folders
        $logFile = Join-Path (Get-LogsPath) ("Manager_" + (Get-Date -Format "yyyy-MM-dd") + ".log")
        $line = "{0} [{1}] {2}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $Level, $Message
        Add-Content -LiteralPath $logFile -Value $line -Encoding UTF8
    } catch {}
}

function Get-IndexPath { Join-Path (Get-DataPath) "bin_index.json" }

function Load-Index {
    $path = Get-IndexPath
    $list = New-Object System.Collections.ArrayList
    if (-not (Test-Path -LiteralPath $path)) { return $list }
    try {
        $raw = Get-Content -LiteralPath $path -Raw -Encoding UTF8
        if ([string]::IsNullOrWhiteSpace($raw)) { return $list }
        $data = $null
        try { $data = $raw | ConvertFrom-Json } catch { return $list }
        if ($null -eq $data) { return $list }
        if ($data -is [System.Array]) {
            foreach ($item in $data) { if ($null -ne $item) { [void]$list.Add($item) } }
        } else {
            [void]$list.Add($data)
        }
    } catch {
        Write-Log "Load-Index error: $_" "ERROR"
    }
    return $list
}

function Save-Index {
    param($Items)
    Ensure-Folders
    $path = Get-IndexPath
    $arr = @()
    if ($null -ne $Items) {
        foreach ($i in @($Items)) {
            if ($null -ne $i) { $arr += $i }
        }
    }
    try {
        if ($arr.Count -eq 0) {
            "[]" | Set-Content -LiteralPath $path -Encoding UTF8
        } else {
            $arr | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $path -Encoding UTF8
        }
    } catch {
        Write-Log "Save-Index error: $_" "ERROR"
    }
}

function Test-IsInsideManager {
    param([string]$FullPath)
    if ([string]::IsNullOrWhiteSpace($FullPath)) { return $false }
    $root = (Get-ManagerRoot).TrimEnd('\')
    $full = $FullPath.TrimEnd('\')
    return $full.StartsWith($root, [StringComparison]::OrdinalIgnoreCase)
}

function Get-RelativePath {
    param([string]$FullPath, [string]$BasePath)
    if ([string]::IsNullOrWhiteSpace($FullPath) -or [string]::IsNullOrWhiteSpace($BasePath)) { return $FullPath }
    $base = $BasePath.TrimEnd('\') + '\'
    if ($FullPath.StartsWith($base, [StringComparison]::OrdinalIgnoreCase)) {
        return $FullPath.Substring($base.Length)
    }
    return $FullPath
}

function New-GuidName { [guid]::NewGuid().ToString("N") }

# Build a full list of Bin items: tracked + auto-adopt any .bat sitting in Bin
function Get-BinItems {
    Ensure-Folders
    $bin   = Get-BinPath
    $root  = Get-ManagerRoot
    $index = Load-Index
    $now   = Get-Date
    $result = New-Object System.Collections.ArrayList

    # 1) Keep valid tracked entries
    $knownNames = @{}
    foreach ($e in $index) {
        if ($null -eq $e) { continue }
        $storedName = $e.StoredName
        if ([string]::IsNullOrWhiteSpace($storedName)) { continue }
        $stored = Join-Path $bin $storedName
        if (-not (Test-Path -LiteralPath $stored)) { continue }

        $knownNames[$storedName] = $true
        try {
            $expire = [datetime]::Parse($e.ExpireTime)
        } catch {
            $expire = $now.AddHours(24)
            $e.ExpireTime = $expire.ToString("o")
        }
        if ($now -ge $expire) { $e.Status = "Expired" } else { $e.Status = "Pending" }
        [void]$result.Add($e)
    }

    # 2) Auto-adopt any other .bat files found in Bin (manual drops or previous orphans)
    if (Test-Path -LiteralPath $bin) {
        $files = Get-ChildItem -LiteralPath $bin -Filter "*.bat" -File -ErrorAction SilentlyContinue
        foreach ($f in $files) {
            if ($knownNames.ContainsKey($f.Name)) { continue }

            # Recover original-looking name from Name__id.bat pattern
            $origName = $f.Name
            if ($f.Name -match '^(.+)__[0-9a-fA-F]+(?:_\d+)?\.bat$') {
                $origName = $Matches[1] + ".bat"
            }

            $entry = [PSCustomObject]@{
                Id               = [guid]::NewGuid().ToString("N")
                OriginalName     = $origName
                OriginalFullPath = (Join-Path $root $origName)
                OriginalRelative = $origName
                OriginalDir      = $root
                StoredName       = $f.Name
                StoredFullPath   = $f.FullName
                MoveTime         = $f.LastWriteTime.ToString("o")
                ExpireTime       = $f.LastWriteTime.AddHours(24).ToString("o")
                Status           = "Pending"
                AutoAdopted      = $true
            }
            [void]$result.Add($entry)
            Write-Log "Auto-adopted Bin file: $($f.Name) as $origName"
        }
    }

    # Persist the unified list
    Save-Index -Items $result
    return $result
}
