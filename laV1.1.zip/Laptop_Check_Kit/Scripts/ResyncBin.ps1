# ResyncBin.ps1 - Force refresh of Bin list (auto-adopts all .bat files in Bin)
. "$PSScriptRoot\Common.ps1"
Ensure-Folders

Write-Host ""
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "  RESYNC BIN" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host ""

$items = Get-BinItems

Write-Host ("Files now tracked in Bin : {0}" -f $items.Count)
Write-Host ""
if ($items.Count -gt 0) {
    foreach ($e in $items) {
        $name = $e.OriginalName
        if ([string]::IsNullOrWhiteSpace($name)) { $name = $e.StoredName }
        Write-Host ("  - {0}" -f $name)
    }
} else {
    Write-Host "Bin is empty."
}
Write-Host ""
Write-Host "Any .bat files that were sitting in the Bin folder"
Write-Host "(including ones added manually) are now in the list."
Write-Host "Use menu option 3 to restore or delete them."
Write-Host ""
