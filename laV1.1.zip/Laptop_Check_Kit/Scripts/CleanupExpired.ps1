# CleanupExpired.ps1
param([switch]$Silent)
. "$PSScriptRoot\Common.ps1"
Ensure-Folders

$lockFile = Join-Path (Get-DataPath) "cleanup.lock"
if (Test-Path -LiteralPath $lockFile) {
    $age = (Get-Date) - (Get-Item -LiteralPath $lockFile).LastWriteTime
    if ($age.TotalMinutes -lt 10) {
        if (-not $Silent) { Write-Host "Cleanup already running or recently finished. Skipping." -ForegroundColor Yellow }
        exit 0
    }
    Remove-Item -LiteralPath $lockFile -Force -ErrorAction SilentlyContinue
}

try {
    "locked" | Set-Content -LiteralPath $lockFile -Encoding ASCII
    if (-not $Silent) { Write-Host "Running expired-item cleanup..." -ForegroundColor Cyan }
    Write-Log "Cleanup started"
    & "$PSScriptRoot\PermanentDelete.ps1" -ExpiredOnly
    Write-Log "Cleanup finished"
}
finally {
    if (Test-Path -LiteralPath $lockFile) {
        Remove-Item -LiteralPath $lockFile -Force -ErrorAction SilentlyContinue
    }
}
