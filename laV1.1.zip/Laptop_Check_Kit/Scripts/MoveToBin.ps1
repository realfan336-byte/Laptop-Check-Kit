# MoveToBin.ps1 - Move selected BAT files into the managed Bin
param(
    [Parameter(Mandatory=$true)]
    [string[]]$Paths,
    [int]$ExpireHours = 24
)

. "$PSScriptRoot\Common.ps1"
Ensure-Folders

$root    = Get-ManagerRoot
$bin     = Get-BinPath
$index   = Load-Index
$results = New-Object System.Collections.ArrayList

if ($null -eq $Paths -or $Paths.Count -eq 0) {
    Write-Host "No paths provided." -ForegroundColor Yellow
    return
}

foreach ($p in $Paths) {
    if ([string]::IsNullOrWhiteSpace($p)) { continue }
    $p = $p.Trim().Trim('"')

    $obj = [PSCustomObject]@{
        Source      = $p
        Success     = $false
        Message     = ""
        StoredName  = $null
        ExpireTime  = $null
    }

    try {
        if (-not (Test-Path -LiteralPath $p -PathType Leaf)) {
            $obj.Message = "File does not exist"
            [void]$results.Add($obj)
            continue
        }

        $item = Get-Item -LiteralPath $p -ErrorAction Stop
        if ($null -eq $item) {
            $obj.Message = "Could not read file info"
            [void]$results.Add($obj)
            continue
        }

        if ($item.Extension -ne ".bat") {
            $obj.Message = "Not a .bat file"
            [void]$results.Add($obj)
            continue
        }

        if (-not (Test-IsInsideManager -FullPath $item.FullName)) {
            $obj.Message = "Path is outside the manager project folder"
            [void]$results.Add($obj)
            continue
        }

        $rel = Get-RelativePath -FullPath $item.FullName -BasePath $root
        if ([string]::IsNullOrWhiteSpace($rel)) { $rel = $item.Name }
        $top = ($rel -split '\\')[0]
        if ($top -in @("Bin","Data","Logs","Scripts") -or $item.Name -eq "BaconBATManager.bat") {
            $obj.Message = "Protected file / folder - cannot move"
            [void]$results.Add($obj)
            continue
        }

        $shortId  = (New-GuidName).Substring(0,8)
        $baseName = [System.IO.Path]::GetFileNameWithoutExtension($item.Name)
        if ([string]::IsNullOrWhiteSpace($baseName)) { $baseName = "file" }
        $storedName = "{0}__{1}.bat" -f $baseName, $shortId
        $dest = Join-Path $bin $storedName

        $n = 1
        while (Test-Path -LiteralPath $dest) {
            $storedName = "{0}__{1}_{2}.bat" -f $baseName, $shortId, $n
            $dest = Join-Path $bin $storedName
            $n++
            if ($n -gt 50) { throw "Too many name collisions in Bin" }
        }

        $moveTime   = Get-Date
        $expireTime = $moveTime.AddHours($ExpireHours)

        Move-Item -LiteralPath $item.FullName -Destination $dest -ErrorAction Stop

        $entry = [PSCustomObject]@{
            Id               = [guid]::NewGuid().ToString("N")
            OriginalName     = $item.Name
            OriginalFullPath = $item.FullName
            OriginalRelative = $rel
            OriginalDir      = $item.DirectoryName
            StoredName       = $storedName
            StoredFullPath   = $dest
            MoveTime         = $moveTime.ToString("o")
            ExpireTime       = $expireTime.ToString("o")
            Status           = "Pending"
        }

        [void]$index.Add($entry)

        $obj.Success    = $true
        $obj.Message    = "Moved successfully"
        $obj.StoredName = $storedName
        $obj.ExpireTime = $expireTime
        Write-Log "Moved to Bin: $rel -> $storedName"
    }
    catch {
        $obj.Message = "Move failed: $($_.Exception.Message)"
        Write-Log "Move failed for $p : $($_.Exception.Message)" "ERROR"
    }

    [void]$results.Add($obj)
}

Save-Index -Items $index

Write-Host ""
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "  MOVE TO BIN - RESULTS" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan

$ok = 0; $fail = 0
foreach ($r in $results) {
    if ($r.Success) {
        $ok++
        Write-Host ("[OK]  {0}" -f $r.Source) -ForegroundColor Green
        if ($null -ne $r.StoredName) {
            Write-Host ("      Stored as: {0}" -f $r.StoredName)
        }
        if ($null -ne $r.ExpireTime) {
            Write-Host ("      Can be restored until: {0}" -f $r.ExpireTime.ToString("yyyy-MM-dd HH:mm"))
        }
    } else {
        $fail++
        Write-Host ("[FAIL] {0}" -f $r.Source) -ForegroundColor Red
        Write-Host ("       {0}" -f $r.Message)
    }
}
Write-Host ""
Write-Host ("Done. Success: {0}  Failed: {1}" -f $ok, $fail)
Write-Host "Files stay recoverable for 24 hours. Use menu option 3 to restore."
Write-Host ""
