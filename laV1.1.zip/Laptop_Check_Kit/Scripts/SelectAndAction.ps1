# SelectAndAction.ps1 - Restore or Delete by number from Bin list JSON
param(
    [Parameter(Mandatory=$true)]
    [ValidateSet("Restore","Delete")]
    [string]$Action,

    [string]$BinJsonFile,
    [string]$Selection
)

$ErrorActionPreference = "Stop"

if ([string]::IsNullOrWhiteSpace($BinJsonFile) -or -not (Test-Path -LiteralPath $BinJsonFile)) {
    Write-Host "Bin list not found. Open the Bin screen first." -ForegroundColor Yellow
    exit 1
}

$raw = Get-Content -LiteralPath $BinJsonFile -Raw -ErrorAction SilentlyContinue
if ([string]::IsNullOrWhiteSpace($raw)) {
    Write-Host "Bin list is empty." -ForegroundColor Yellow
    exit 1
}

try { $json = $raw | ConvertFrom-Json } catch {
    Write-Host "Could not read Bin list." -ForegroundColor Red
    exit 1
}

if ($null -eq $json) { $json = @() }
if ($json -isnot [System.Array]) { $json = @($json) }

if ($json.Count -eq 0) {
    Write-Host "Bin is empty - nothing to $Action." -ForegroundColor Yellow
    exit 1
}

$sel = ""
if (-not [string]::IsNullOrWhiteSpace($Selection)) { $sel = $Selection.Trim() }

$ids = New-Object System.Collections.ArrayList
$nums = $sel -split '\s+' | Where-Object { $_ -match '^\d+$' }
foreach ($n in $nums) {
    $i = [int]$n - 1
    if ($i -ge 0 -and $i -lt $json.Count) {
        $item = $json[$i]
        if ($null -ne $item -and -not [string]::IsNullOrWhiteSpace($item.Id)) {
            [void]$ids.Add([string]$item.Id)
        }
    }
}

if ($ids.Count -eq 0) {
    Write-Host "No valid number. Type the number shown in the list (e.g. 1)." -ForegroundColor Yellow
    exit 1
}

if ($Action -eq "Restore") {
    & "$PSScriptRoot\Restore.ps1" -Ids ([string[]]$ids.ToArray())
} else {
    & "$PSScriptRoot\PermanentDelete.ps1" -Ids ([string[]]$ids.ToArray())
}
