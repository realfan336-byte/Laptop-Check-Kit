# SelectAndMove.ps1 - Read scan JSON + user selection, then call MoveToBin
param(
    [string]$ScanJsonFile,
    [string]$Selection,
    [int]$ExpireHours = 24
)

$ErrorActionPreference = "Stop"

if ([string]::IsNullOrWhiteSpace($ScanJsonFile) -or -not (Test-Path -LiteralPath $ScanJsonFile)) {
    Write-Host "Scan data not found. Run Scan first." -ForegroundColor Yellow
    exit 1
}

$raw = Get-Content -LiteralPath $ScanJsonFile -Raw -ErrorAction SilentlyContinue
if ([string]::IsNullOrWhiteSpace($raw)) {
    Write-Host "Scan data is empty." -ForegroundColor Yellow
    exit 1
}

try {
    $json = $raw | ConvertFrom-Json
} catch {
    Write-Host "Could not read scan data." -ForegroundColor Red
    exit 1
}

if ($null -eq $json) { $json = @() }
if ($json -isnot [System.Array]) { $json = @($json) }

$sel = ""
if (-not [string]::IsNullOrWhiteSpace($Selection)) { $sel = $Selection.Trim() }

$paths = New-Object System.Collections.ArrayList

if ($sel -eq "ALL") {
    foreach ($item in $json) {
        if ($null -ne $item -and -not [string]::IsNullOrWhiteSpace($item.FullName)) {
            [void]$paths.Add([string]$item.FullName)
        }
    }
} else {
    $nums = $sel -split '\s+' | Where-Object { $_ -match '^\d+$' }
    foreach ($n in $nums) {
        $i = [int]$n - 1
        if ($i -ge 0 -and $i -lt $json.Count) {
            $item = $json[$i]
            if ($null -ne $item -and -not [string]::IsNullOrWhiteSpace($item.FullName)) {
                [void]$paths.Add([string]$item.FullName)
            }
        }
    }
}

if ($paths.Count -eq 0) {
    Write-Host "No valid selection. Type numbers from the list (e.g. 1 2) or ALL." -ForegroundColor Yellow
    exit 1
}

& "$PSScriptRoot\MoveToBin.ps1" -Paths ([string[]]$paths.ToArray()) -ExpireHours $ExpireHours
