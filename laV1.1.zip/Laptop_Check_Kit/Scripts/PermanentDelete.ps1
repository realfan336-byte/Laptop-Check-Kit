# PermanentDelete.ps1
param(
    [string[]]$Ids,
    [switch]$ExpiredOnly,
    [switch]$All
)

. "$PSScriptRoot\Common.ps1"
Ensure-Folders

$items = Get-BinItems
$bin   = Get-BinPath
$now   = Get-Date
$results = New-Object System.Collections.ArrayList
$keep = New-Object System.Collections.ArrayList

foreach ($e in $items) {
    if ($null -eq $e) { continue }
    $shouldDelete = $false

    if ($All) {
        $shouldDelete = $true
    } elseif ($ExpiredOnly) {
        try {
            $expire = [datetime]::Parse($e.ExpireTime)
            if ($now -ge $expire) { $shouldDelete = $true }
        } catch { }
    } elseif ($Ids -and ($Ids -contains $e.Id)) {
        $shouldDelete = $true
    }

    if (-not $shouldDelete) {
        [void]$keep.Add($e)
        continue
    }

    $obj = [PSCustomObject]@{
        Id      = $e.Id
        Name    = $e.OriginalName
        Success = $false
        Message = ""
    }

    $stored = Join-Path $bin $e.StoredName

    # Safety: only delete inside our Bin
    if (-not $stored.StartsWith($bin, [StringComparison]::OrdinalIgnoreCase)) {
        $obj.Message = "Safety block: path is not inside Bin"
        [void]$results.Add($obj)
        [void]$keep.Add($e)
        Write-Log "Safety block on delete: $stored" "ERROR"
        continue
    }

    try {
        if (Test-Path -LiteralPath $stored) {
            Remove-Item -LiteralPath $stored -Force -ErrorAction Stop
            $obj.Success = $true
            $obj.Message = "Permanently deleted"
            Write-Log "Permanently deleted: $($e.OriginalName)"
        } else {
            $obj.Success = $true
            $obj.Message = "File already missing - removed from list"
        }
    } catch {
        $obj.Message = "Delete failed: $($_.Exception.Message)"
        Write-Log "Delete failed: $($e.OriginalName) - $_" "ERROR"
        [void]$keep.Add($e)
    }
    [void]$results.Add($obj)
}

Save-Index -Items $keep

Write-Host ""
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "  PERMANENT DELETE RESULTS" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
if ($results.Count -eq 0) {
    Write-Host "Nothing to delete." -ForegroundColor Yellow
} else {
    foreach ($r in $results) {
        if ($r.Success) {
            Write-Host ("[OK]   {0} - {1}" -f $r.Name, $r.Message) -ForegroundColor Green
        } else {
            Write-Host ("[FAIL] {0} - {1}" -f $r.Name, $r.Message) -ForegroundColor Red
        }
    }
}
Write-Host ""
