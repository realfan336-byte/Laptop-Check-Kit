# ListBin.ps1 - Show Bin contents (auto-adopts any .bat found in Bin)
param([switch]$Quiet)

. "$PSScriptRoot\Common.ps1"
Ensure-Folders

$items = Get-BinItems   # this also auto-adopts orphans and saves index
$now   = Get-Date
$bin   = Get-BinPath

if (-not $Quiet) {
    Write-Host ""
    Write-Host "============================================================" -ForegroundColor Cyan
    Write-Host "  BIN / RECOVERY LIST" -ForegroundColor Cyan
    Write-Host "============================================================" -ForegroundColor Cyan
    Write-Host ("Location : {0}" -f $bin)
    Write-Host ("Files    : {0}" -f $items.Count)
    Write-Host ""

    if ($items.Count -eq 0) {
        Write-Host "The Bin is empty." -ForegroundColor Yellow
    } else {
        $i = 1
        foreach ($e in $items) {
            try { $expire = [datetime]::Parse($e.ExpireTime) } catch { $expire = $now.AddHours(24) }
            $remain = $expire - $now
            if ($remain.TotalSeconds -lt 0) {
                $remainText = "EXPIRED - will be removed on next cleanup"
                $color = "Red"
            } else {
                $h = [math]::Floor($remain.TotalHours)
                $m = $remain.Minutes
                $remainText = "{0}h {1}m left to restore" -f $h, $m
                $color = "Green"
            }
            $name = $e.OriginalName
            if ([string]::IsNullOrWhiteSpace($name)) { $name = $e.StoredName }
            Write-Host ("  {0,3}. {1}" -f $i, $name) -ForegroundColor $color
            if (-not [string]::IsNullOrWhiteSpace($e.OriginalRelative)) {
                Write-Host ("       From     : {0}" -f $e.OriginalRelative)
            }
            try {
                Write-Host ("       Moved    : {0}" -f ([datetime]::Parse($e.MoveTime).ToString("yyyy-MM-dd HH:mm")))
            } catch {}
            Write-Host ("       Status   : {0}" -f $remainText)
            Write-Host ""
            $i++
        }
    }
}

if ($Quiet) {
    # Output clean JSON array for the BAT to read
    if ($items.Count -eq 0) {
        "[]"
    } else {
        @($items) | ConvertTo-Json -Depth 6
    }
}
