# Restore.ps1
param(
    [Parameter(Mandatory=$true)]
    [string[]]$Ids
)

. "$PSScriptRoot\Common.ps1"
Ensure-Folders

$items  = Get-BinItems
$bin    = Get-BinPath
$results = New-Object System.Collections.ArrayList
$keep    = New-Object System.Collections.ArrayList

$lookup = @{}
foreach ($e in $items) {
    if ($null -ne $e -and -not [string]::IsNullOrWhiteSpace($e.Id)) {
        $lookup[$e.Id] = $e
    }
}

$requested = @{}
foreach ($id in $Ids) { $requested[$id] = $true }

foreach ($e in $items) {
    if ($null -eq $e) { continue }

    if (-not $requested.ContainsKey($e.Id)) {
        [void]$keep.Add($e)
        continue
    }

    $obj = [PSCustomObject]@{
        Id      = $e.Id
        Success = $false
        Message = ""
    }

    $stored = Join-Path $bin $e.StoredName

    try {
        if (-not (Test-Path -LiteralPath $stored)) {
            $obj.Message = "Stored file missing from Bin"
            [void]$results.Add($obj)
            continue
        }

        $destDir  = $e.OriginalDir
        $destFile = Join-Path $destDir $e.OriginalName

        if ([string]::IsNullOrWhiteSpace($destDir) -or -not (Test-IsInsideManager -FullPath $destDir)) {
            # Fallback: restore to project root
            $destDir  = Get-ManagerRoot
            $destFile = Join-Path $destDir $e.OriginalName
        }

        if (-not (Test-Path -LiteralPath $destDir)) {
            New-Item -ItemType Directory -Path $destDir -Force | Out-Null
        }

        if (Test-Path -LiteralPath $destFile) {
            $obj.Message = "A file with the same name already exists at the original location. Restore cancelled to avoid overwrite."
            [void]$results.Add($obj)
            [void]$keep.Add($e)
            continue
        }

        Move-Item -LiteralPath $stored -Destination $destFile -ErrorAction Stop
        $obj.Success = $true
        $obj.Message = "Restored to $destFile"
        Write-Log "Restored: $($e.OriginalName) -> $destFile"
    }
    catch {
        $obj.Message = "Restore failed: $($_.Exception.Message)"
        Write-Log "Restore failed for $($e.Id): $_" "ERROR"
        [void]$keep.Add($e)
    }

    [void]$results.Add($obj)
}

Save-Index -Items $keep

Write-Host ""
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "  RESTORE RESULTS" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
foreach ($r in $results) {
    if ($r.Success) {
        Write-Host ("[OK]   {0}" -f $r.Message) -ForegroundColor Green
    } else {
        Write-Host ("[FAIL] {0}" -f $r.Message) -ForegroundColor Red
    }
}
Write-Host ""
