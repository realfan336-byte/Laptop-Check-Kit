@echo off
setlocal EnableDelayedExpansion
title Bacon Windows Tools - Windows Error Finder
color 0C

REM ============================================================
REM  Windows_Error_Finder.bat
REM  Recent System errors, critical events, unexpected shutdowns
REM  Creates its own folder and Reports subfolder if missing
REM ============================================================

set "SCRIPT_DIR=%~dp0"
if "%SCRIPT_DIR:~-1%"=="\" set "SCRIPT_DIR=%SCRIPT_DIR:~0,-1%"

REM Ensure the script folder exists
if not exist "%SCRIPT_DIR%" (
    echo [ERROR] Script directory not found.
    pause
    exit /b 1
)

REM Create Reports subfolder if missing
set "REPORTS=%SCRIPT_DIR%\Reports"
if not exist "%REPORTS%" (
    echo Creating Reports folder...
    mkdir "%REPORTS%" 2>nul
    if errorlevel 1 (
        echo [ERROR] Cannot create Reports folder: %REPORTS%
        pause
        exit /b 1
    )
)

REM Timestamp
for /f "tokens=2 delims==" %%a in ('wmic os get localdatetime /value 2^>nul') do set "dt=%%a"
if defined dt (
    set "TS=%dt:~0,4%-%dt:~4,2%-%dt:~6,2%_%dt:~8,2%-%dt:~10,2%-%dt:~12,2%"
) else (
    set "TS=%date:~-4,4%-%date:~-10,2%-%date:~-7,2%_%time:~0,2%-%time:~3,2%-%time:~6,2%"
    set "TS=%TS: =0%"
)

set "REPORT=%REPORTS%\Error_Finder_%TS%.txt"

echo ============================================================
echo   WINDOWS ERROR FINDER
echo ============================================================
echo.
echo This tool reads recent System event log entries for:
echo   - Critical events
echo   - Error events
echo   - Unexpected shutdowns / Kernel-Power events
echo.
echo It does NOT clear any logs or change system settings.
echo.
echo Report will be saved to:
echo   %REPORT%
echo.

REM Check for wevtutil
where wevtutil >nul 2>&1
if errorlevel 1 (
    echo [ERROR] wevtutil is not available on this system.
    echo Cannot continue.
    pause
    exit /b 1
)

(
    echo Bacon Windows Tools - Windows Error Finder Report
    echo Generated: %date% %time%
    echo Computer: %COMPUTERNAME%
    echo User: %USERNAME%
    echo ============================================================
    echo.
    echo Note: Full access to event logs often requires running
    echo this script as Administrator. Permission errors will be
    echo reported clearly.
    echo.
) > "%REPORT%"

echo [1/4] Checking for Administrator rights...
net session >nul 2>&1
if errorlevel 1 (
    echo [INFO] Not running as Administrator.
    echo Some event log entries may be inaccessible.
    echo [INFO] Not running elevated >> "%REPORT%"
) else (
    echo Running with Administrator privileges.
    echo [INFO] Running elevated >> "%REPORT%"
)
echo.

echo [2/4] Recent Critical and Error events (System log, last 40)...
echo ----- Critical / Error Events (last 40) ----- >> "%REPORT%"
wevtutil qe System /q:"*[System[(Level=1 or Level=2)]]" /f:text /c:40 /rd:true >> "%REPORT%" 2>&1
if errorlevel 1 (
    echo [WARN] Query returned an error (possible access denied).
    echo [WARN] Critical/Error query failed or access denied >> "%REPORT%"
) else (
    echo Query completed.
)
echo. >> "%REPORT%"

echo.
echo [3/4] Unexpected shutdown / Kernel-Power events...
echo ----- Kernel-Power / Unexpected Shutdown ----- >> "%REPORT%"
wevtutil qe System /q:"*[System[Provider[@Name='Microsoft-Windows-Kernel-Power'] and (EventID=41 or EventID=42 or EventID=109)]]" /f:text /c:20 /rd:true >> "%REPORT%" 2>&1
if errorlevel 1 (
    echo [WARN] Kernel-Power query had an issue.
    echo [WARN] Kernel-Power query issue >> "%REPORT%"
) else (
    echo Query completed.
)
echo. >> "%REPORT%"

echo.
echo [4/4] BugCheck / WER related entries (if any)...
echo ----- BugCheck / WER SystemErrorReporting ----- >> "%REPORT%"
wevtutil qe System /q:"*[System[Provider[@Name='Microsoft-Windows-WER-SystemErrorReporting'] or Provider[@Name='BugCheck'] or (EventID=1001)]]" /f:text /c:15 /rd:true >> "%REPORT%" 2>&1
if errorlevel 1 (
    echo [WARN] BugCheck/WER query had an issue.
    echo [WARN] BugCheck/WER query issue >> "%REPORT%"
) else (
    echo Query completed.
)
echo. >> "%REPORT%"

echo.
echo Additional short warning events (last 15)...
echo ----- Recent Warnings (last 15) ----- >> "%REPORT%"
wevtutil qe System /q:"*[System[(Level=3)]]" /f:text /c:15 /rd:true >> "%REPORT%" 2>&1
echo. >> "%REPORT%"

echo.
echo ============================================================
echo   DONE
echo ============================================================
echo.
echo Report saved to:
echo   %REPORT%
echo.
echo How to read the report:
echo - Look for timestamps, Event ID, Source, and Level.
echo - Event ID 41 (Kernel-Power) often indicates an unexpected
echo   shutdown or power loss.
echo - Empty sections usually mean no matching events were found
echo   or access was limited.
echo.
echo This tool never clears event logs.
echo.

echo Opening Reports folder and the report...
start "" explorer "%REPORTS%"
timeout /t 1 >nul
if exist "%REPORT%" start notepad "%REPORT%"

echo.
echo Press any key to exit...
pause >nul
exit /b 0
