================================================================================
  LAPTOP CHECK KIT
  Real Windows Diagnostic Scripts (No Fake Results)
================================================================================

WHAT THIS KIT IS
----------------
A collection of batch scripts that use genuine built-in Windows tools
(systeminfo, wmic, powershell, chkdsk, mdsched, powercfg, sfc, DISM,
wevtutil, ipconfig, ping, etc.) to collect information and run safe
checks on a Windows 10 (and similar) PC.

Nothing in this kit invents measurements or pretends a test passed
when it did not run.


HOW TO EXTRACT AND START
------------------------
1. Extract the entire ZIP to any folder (Desktop, Documents, USB, etc.).
2. Open the extracted folder "Laptop_Check_Kit".
3. Double-click START_HERE.bat
   - It checks the folder structure.
   - Shows your Windows version.
   - Opens this README.
   - Launches the main menu (ALL_TESTS.bat).

You can also run ALL_TESTS.bat or any individual *.bat file directly.


FOLDER STRUCTURE
----------------
Laptop_Check_Kit/
├── START_HERE.bat          <-- Begin here
├── ALL_TESTS.bat           <-- Main menu
├── CPU_TEST.bat
├── RAM_TEST.bat
├── DISK_TEST.bat
├── SYSTEM_INFO.bat
├── BATTERY_TEST.bat
├── NETWORK_TEST.bat
├── WINDOWS_HEALTH_TEST.bat
├── EVENT_LOG_TEST.bat
├── CHECK_FILES.bat
├── CRASH_DEMO.bat          <-- Visual simulation only (does NOT crash Windows)
├── README.txt              <-- This file
├── LICENSE.txt
├── Reports/                <-- Reports are saved here (auto-created)
└── Support/
    └── common.bat          <-- Shared helper (do not run directly)


WHAT EACH TEST REALLY CHECKS
----------------------------
SYSTEM_INFO.bat
  Collects real systeminfo, CPU, memory, Windows version, graphics,
  and disk details via built-in commands. Saves a text report.

CPU_TEST.bat
  Runs a genuine, time-bounded CPU workload using PowerShell jobs.
  You choose duration (15/30/60 seconds). Completing the test only
  means the system stayed responsive; it does NOT prove the CPU is
  healthy. Stop if the laptop becomes excessively hot or unstable.

RAM_TEST.bat
  Launches the real Windows Memory Diagnostic (mdsched.exe).
  The actual test normally requires a restart. This script never
  pretends RAM was checked if you did not run the diagnostic.
  Results appear later in Event Viewer under MemoryDiagnostics-Results.

DISK_TEST.bat
  Lists logical drives and free space. Runs chkdsk in READ-ONLY mode
  (no /f, no /r). Attempts to query physical disk health via
  PowerShell Get-PhysicalDisk when available. Never formats or
  repairs drives automatically.

BATTERY_TEST.bat
  Queries battery presence/status via WMIC and can generate a
  powercfg battery report HTML file. Clearly reports when no battery
  data is available (e.g. desktop or missing battery).

NETWORK_TEST.bat
  Shows adapter configuration, gateway, DNS, and tests connectivity
  to a reliable public host (1.1.1.1). Distinguishes local vs
  internet reachability. Does not display Wi-Fi passwords.

WINDOWS_HEALTH_TEST.bat
  Offers sfc /verifyonly and DISM /CheckHealth (and optional
  ScanHealth). These can take a long time and work best as
  Administrator. No automatic repairs are started.

EVENT_LOG_TEST.bat
  Reads recent Error and Warning events from the System log with
  wevtutil. Handles access-denied situations.

CHECK_FILES.bat
  Verifies that all expected kit files and folders exist and that
  common Windows tools are present on the system.

CRASH_DEMO.bat
  SIMULATION ONLY. Displays text that resembles an old-style
  Windows Stop error screen. It does NOT crash Windows, trigger a
  real BSOD, kill processes, or modify the system.


WHICH TESTS NEED ADMINISTRATOR PERMISSION
-----------------------------------------
Strongly recommended or required for full results:
  - WINDOWS_HEALTH_TEST.bat (sfc, DISM)
  - EVENT_LOG_TEST.bat (some event log access)
  - DISK_TEST.bat (chkdsk may need elevation on some volumes)
  - RAM_TEST.bat (mdsched may prompt for elevation)

Right-click the .bat file and choose "Run as administrator" when
needed. The scripts will warn you if elevation is missing.


WHICH TESTS REQUIRE A RESTART
-----------------------------
  - RAM_TEST.bat (Windows Memory Diagnostic typically runs after reboot)

No other test in this kit restarts Windows automatically.


WHERE REPORTS ARE SAVED
-----------------------
All reports go into the Reports folder inside the kit:

  Laptop_Check_Kit\Reports\

Filenames include a timestamp, for example:
  SystemInfo_2026-10-25_18-30-45.txt
  Disk_Test_2026-10-25_18-35-12.txt
  battery-report_2026-10-25_18-40-00.html

The Reports folder is created automatically if missing.


WHEN A COMMAND IS UNSUPPORTED
-----------------------------
Scripts check for tools and report errors clearly. They do not
silently treat a missing or failed diagnostic as a success.
On older or restricted systems some commands (especially certain
PowerShell disk health queries) may be unavailable; the report
will say so.


WHY A SUCCESSFUL TEST DOES NOT GUARANTEE HEALTH
-----------------------------------------------
- Hardware can fail intermittently.
- A short CPU workload does not exercise every failure mode.
- chkdsk read-only only reports what it finds at that moment.
- SMART/health data is often not exposed to Windows.
- Software checks cannot see every physical defect.

Use the results as information, not as a complete certification
that the laptop is problem-free.


HOW TO STOP A RUNNING TEST SAFELY
---------------------------------
- CPU workload: Press Ctrl+C in the console window.
- Long chkdsk or sfc/DISM: Ctrl+C (may take a moment to stop cleanly).
- Close the window only as a last resort.
- Never force power-off during a disk check if possible.


COMPLETE FILE LISTING
---------------------
START_HERE.bat
ALL_TESTS.bat
CPU_TEST.bat
RAM_TEST.bat
DISK_TEST.bat
SYSTEM_INFO.bat
BATTERY_TEST.bat
NETWORK_TEST.bat
WINDOWS_HEALTH_TEST.bat
EVENT_LOG_TEST.bat
CHECK_FILES.bat
CRASH_DEMO.bat
README.txt
LICENSE.txt
Support\common.bat
Reports\          (folder, initially empty)


SAFETY
------
- No script formats, repartitions, or automatically repairs drives.
- No script disables Windows security features.
- No script intentionally crashes the system.
- CRASH_DEMO.bat is a visual simulation only.


SUPPORT
-------
This is a self-contained kit. It does not require internet access,
Python, GitHub, or paid software to run the diagnostics.

================================================================================
