# Common.ps1 - Shared helpers for Bacon Drive Scanner
$ErrorActionPreference = "Continue"

function Get-ScannerRoot {
    $d = $PSScriptRoot
    if (-not $d) { $d = Split-Path -Parent $MyInvocation.MyCommand.Path }
    return (Resolve-Path (Join-Path $d "..")).Path
}

function Get-LogsPath    { Join-Path (Get-ScannerRoot) "Logs" }
function Get-ReportsPath { Join-Path (Get-ScannerRoot) "Reports" }
function Get-DataPath    { Join-Path (Get-ScannerRoot) "Data" }
function Get-ConfigPath  { Join-Path (Get-ScannerRoot) "Config" }

function Ensure-OutputFolders {
    $root = Get-ScannerRoot
    $ok = $true
    foreach ($name in @("Logs","Reports","Data","Config")) {
        $p = Join-Path $root $name
        if (-not (Test-Path -LiteralPath $p)) {
            try {
                New-Item -ItemType Directory -Path $p -Force | Out-Null
            } catch {
                Write-Host "[ERROR] Cannot create folder: $p" -ForegroundColor Red
                Write-Host "  $_"
                $ok = $false
            }
        }
        # writability check
        $testFile = Join-Path $p ("_write_test_" + [guid]::NewGuid().ToString("N") + ".tmp")
        try {
            "ok" | Set-Content -LiteralPath $testFile -ErrorAction Stop
            Remove-Item -LiteralPath $testFile -Force -ErrorAction SilentlyContinue
        } catch {
            Write-Host "[ERROR] Folder not writable: $p" -ForegroundColor Red
            $ok = $false
        }
    }
    return $ok
}

function Get-Timestamp { Get-Date -Format "yyyy-MM-dd_HHmmss" }

function Write-ScanLog {
    param([string]$Message, [string]$Level = "INFO", [string]$LogFile)
    if (-not $LogFile) { return }
    $line = "{0} [{1}] {2}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $Level, $Message
    try { Add-Content -LiteralPath $LogFile -Value $line -Encoding UTF8 } catch {}
}

function Format-Size {
    param([long]$Bytes)
    if ($Bytes -ge 1GB) { return "{0:N2} GB" -f ($Bytes / 1GB) }
    if ($Bytes -ge 1MB) { return "{0:N2} MB" -f ($Bytes / 1MB) }
    if ($Bytes -ge 1KB) { return "{0:N2} KB" -f ($Bytes / 1KB) }
    return "$Bytes B"
}

function Get-FileCategory {
    param([string]$Ext)
    if ([string]::IsNullOrWhiteSpace($Ext)) { return "Other" }
    $e = $Ext.TrimStart('.').ToLowerInvariant()
    switch ($e) {
        { $_ -in @("jpg","jpeg","png","webp","bmp","gif","tiff","tif","ico","heic","heif","svg","raw","cr2","nef") } { return "Image" }
        { $_ -in @("mp4","mkv","avi","mov","wmv","webm","m4v","flv","mpeg","mpg","3gp") } { return "Video" }
        { $_ -in @("mp3","wav","flac","aac","m4a","ogg","wma","aiff","opus") } { return "Audio" }
        { $_ -in @("pdf","doc","docx","txt","rtf","xlsx","xls","pptx","ppt","csv","odt","ods","odp","md") } { return "Document" }
        { $_ -in @("zip","7z","rar","tar","gz","bz2","xz","iso","cab") } { return "Archive" }
        { $_ -in @("exe","msi","bat","cmd","ps1","vbs","js","py","com","scr","dll","sys") } { return "Application" }
        default { return "Other" }
    }
}

function Get-LocalDrives {
    $list = New-Object System.Collections.ArrayList
    try {
        $vols = Get-WmiObject Win32_LogicalDisk -ErrorAction SilentlyContinue
        if (-not $vols) { $vols = Get-CimInstance Win32_LogicalDisk -ErrorAction SilentlyContinue }
        foreach ($v in $vols) {
            # DriveType: 2=Removable, 3=Local, 4=Network, 5=CD
            $typeName = switch ([int]$v.DriveType) {
                2 { "Removable" }
                3 { "Local" }
                4 { "Network" }
                5 { "Optical" }
                default { "Other" }
            }
            # Skip optical if not ready
            if ([int]$v.DriveType -eq 5) {
                try {
                    $null = Get-ChildItem -LiteralPath ($v.DeviceID + "\") -ErrorAction Stop
                } catch { continue }
            }
            $obj = [PSCustomObject]@{
                Letter      = $v.DeviceID
                Label       = $v.VolumeName
                FileSystem  = $v.FileSystem
                SizeBytes   = [long]$v.Size
                FreeBytes   = [long]$v.FreeSpace
                UsedBytes   = [long]($v.Size - $v.FreeSpace)
                DriveType   = $typeName
                Ready       = $true
            }
            [void]$list.Add($obj)
        }
    } catch {
        Write-Host "Drive discovery error: $_" -ForegroundColor Red
    }
    return $list
}
