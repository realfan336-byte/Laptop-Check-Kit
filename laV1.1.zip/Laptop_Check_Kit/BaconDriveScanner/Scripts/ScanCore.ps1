# ScanCore.ps1 - Main scanning engine (low-memory, streaming CSV)
param(
    [string[]]$DriveLetters,   # e.g. "C:","D:"  - if empty, all local/removable
    [switch]$ListOnly          # just list drives and exit
)

. "$PSScriptRoot\Common.ps1"

if (-not (Ensure-OutputFolders)) {
    Write-Host "Cannot create or write to output folders. Fix permissions and try again." -ForegroundColor Red
    exit 1
}

$ts = Get-Timestamp
$scanId = "SCAN_$ts"
$logFile     = Join-Path (Get-LogsPath)    ("Drive_Scanner_Log_$ts.log")
$reportFile  = Join-Path (Get-ReportsPath) ("Drive_Scan_Report_$ts.txt")
$driveCsv    = Join-Path (Get-DataPath)    ("Drive_Summary_$ts.csv")
$fileCsv     = Join-Path (Get-DataPath)    ("File_Inventory_$ts.csv")
$folderCsv   = Join-Path (Get-DataPath)    ("Folder_Inventory_$ts.csv")
$photoCsv    = Join-Path (Get-DataPath)    ("Photo_Inventory_$ts.csv")
$errorCsv    = Join-Path (Get-DataPath)    ("Scan_Errors_$ts.csv")
$metaJson    = Join-Path (Get-DataPath)    ("Scan_Metadata_$ts.json")
$stopFlag    = Join-Path (Get-ConfigPath)  "STOP_SCAN.flag"

# Remove stale stop flag
if (Test-Path -LiteralPath $stopFlag) { Remove-Item -LiteralPath $stopFlag -Force -ErrorAction SilentlyContinue }

Write-ScanLog "Scan started. ID=$scanId" "INFO" $logFile
Write-ScanLog "Scanner root: $(Get-ScannerRoot)" "INFO" $logFile

$allDrives = Get-LocalDrives
if ($ListOnly) {
    Write-Host ""
    Write-Host "Discovered drives:" -ForegroundColor Cyan
    $i = 1
    foreach ($d in $allDrives) {
        $label = if ($d.Label) { $d.Label } else { "(no label)" }
        Write-Host ("  {0}. {1}  [{2}]  {3}  Free: {4} / {5}" -f $i, $d.Letter, $d.DriveType, $label, (Format-Size $d.FreeBytes), (Format-Size $d.SizeBytes))
        $i++
    }
    Write-Host ""
    return $allDrives
}

# Select drives
$targets = New-Object System.Collections.ArrayList
if ($DriveLetters -and $DriveLetters.Count -gt 0) {
    foreach ($dl in $DriveLetters) {
        $norm = $dl.Trim().TrimEnd('\').ToUpperInvariant()
        if ($norm -notmatch '^[A-Z]:$') { $norm = $norm + ":" }
        $match = $allDrives | Where-Object { $_.Letter.ToUpperInvariant() -eq $norm }
        if ($match) { [void]$targets.Add($match) }
        else { Write-ScanLog "Requested drive not found or not ready: $dl" "WARNING" $logFile }
    }
} else {
    foreach ($d in $allDrives) {
        if ($d.DriveType -in @("Local","Removable")) { [void]$targets.Add($d) }
    }
}

if ($targets.Count -eq 0) {
    Write-Host "No drives to scan." -ForegroundColor Yellow
    Write-ScanLog "No drives to scan." "WARNING" $logFile
    exit 1
}

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "       BACON DRIVE SCANNER" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Scan ID : $scanId"
Write-Host "Drives  : $($targets.Count)"
Write-Host "Output  : $(Get-ScannerRoot)"
Write-Host "To stop : create file Config\STOP_SCAN.flag  or press Ctrl+C"
Write-Host ""

# Prepare CSV headers (streaming)
"DriveLetter,Label,FileSystem,DriveType,SizeBytes,FreeBytes,UsedBytes,FilesFound,FoldersFound,Errors,Status,StartTime,EndTime" | Set-Content -LiteralPath $driveCsv -Encoding UTF8
"DriveLetter,FullPath,FileName,Extension,Category,SizeBytes,SizeReadable,CreationTime,LastWriteTime,Attributes,Status" | Set-Content -LiteralPath $fileCsv -Encoding UTF8
"DriveLetter,FullPath,FolderName,ParentPath,Status" | Set-Content -LiteralPath $folderCsv -Encoding UTF8
"DriveLetter,FullPath,FileName,Extension,SizeBytes,SizeReadable,CreationTime,LastWriteTime" | Set-Content -LiteralPath $photoCsv -Encoding UTF8
"Timestamp,DriveLetter,Path,ErrorMessage" | Set-Content -LiteralPath $errorCsv -Encoding UTF8

function Escape-Csv([string]$s) {
    if ($null -eq $s) { return "" }
    $s = $s -replace '"', '""'
    if ($s -match '[,"\r\n]') { return '"' + $s + '"' }
    return $s
}

$scanStart = Get-Date
$totalFiles = 0
$totalFolders = 0
$totalBytes = [long]0
$totalErrors = 0
$catCounts = @{}
$driveResults = New-Object System.Collections.ArrayList
$stopped = $false
$drivesDone = 0

foreach ($drv in $targets) {
    if (Test-Path -LiteralPath $stopFlag) {
        $stopped = $true
        Write-ScanLog "Stop flag detected before drive $($drv.Letter)" "INFO" $logFile
        break
    }

    $rootPath = $drv.Letter + "\"
    $drvStart = Get-Date
    $filesOnDrive = 0
    $foldersOnDrive = 0
    $errorsOnDrive = 0
    $status = "Completed"
    $currentFolder = $rootPath

    Write-ScanLog "Scanning drive $($drv.Letter) ($($drv.DriveType))" "INFO" $logFile

    # Progress header
    Clear-Host
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host "       BACON DRIVE SCANNER" -ForegroundColor Cyan
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host ""
    Write-Host ("Status          : Scanning {0}" -f $drv.Letter)
    Write-Host ("Current folder  : {0}" -f $currentFolder)
    Write-Host ("Files so far    : {0:N0}" -f $totalFiles)
    Write-Host ("Folders so far  : {0:N0}" -f $totalFolders)
    Write-Host ("Data recorded   : {0}" -f (Format-Size $totalBytes))
    Write-Host ("Errors          : {0}" -f $totalErrors)
    Write-Host ("Drives progress : {0} / {1}" -f $drivesDone, $targets.Count)
    Write-Host ""
    $pct = [int](($drivesDone / [math]::Max($targets.Count,1)) * 100)
    $barLen = 30
    $filled = [int]($barLen * $drivesDone / [math]::Max($targets.Count,1))
    $bar = ("#" * $filled) + ("." * ($barLen - $filled))
    Write-Host ("Progress: [{0}] {1}%  (drive-level)" -f $bar, $pct)
    Write-Host ""
    Write-Host "Please wait. Do not close this window."
    Write-Host "To stop safely: create Config\STOP_SCAN.flag"
    Write-Host ""

    # Enumerate with Directory.Enumerate* for low memory (via .NET)
    $fileBuffer = New-Object System.Collections.Generic.List[string]
    $folderBuffer = New-Object System.Collections.Generic.List[string]
    $photoBuffer = New-Object System.Collections.Generic.List[string]
    $errorBuffer = New-Object System.Collections.Generic.List[string]
    $flushEvery = 200
    $itemsSinceFlush = 0
    $lastUiUpdate = Get-Date

    try {
        $dirEnum = [System.IO.Directory]::EnumerateDirectories($rootPath, "*", [System.IO.SearchOption]::AllDirectories)
        $fileEnum = [System.IO.Directory]::EnumerateFiles($rootPath, "*", [System.IO.SearchOption]::AllDirectories)
    } catch {
        $msg = $_.Exception.Message
        Write-ScanLog "Cannot start enumeration on $($drv.Letter): $msg" "ERROR" $logFile
        $errorBuffer.Add((("{0},{1},{2},{3}" -f (Get-Date -Format "o"), (Escape-Csv $drv.Letter), (Escape-Csv $rootPath), (Escape-Csv $msg))))
        $errorsOnDrive++
        $totalErrors++
        $status = "Failed"
        $dirEnum = @()
        $fileEnum = @()
    }

    # Folders
    try {
        foreach ($dirPath in $dirEnum) {
            if (Test-Path -LiteralPath $stopFlag) { $stopped = $true; $status = "Stopped"; break }
            try {
                $name = [System.IO.Path]::GetFileName($dirPath)
                $parent = [System.IO.Path]::GetDirectoryName($dirPath)
                $line = "{0},{1},{2},{3},{4}" -f `
                    (Escape-Csv $drv.Letter),
                    (Escape-Csv $dirPath),
                    (Escape-Csv $name),
                    (Escape-Csv $parent),
                    "OK"
                $folderBuffer.Add($line)
                $foldersOnDrive++
                $totalFolders++
                $currentFolder = $dirPath
                $itemsSinceFlush++
            } catch {
                $msg = $_.Exception.Message
                $errorBuffer.Add(("{0},{1},{2},{3}" -f (Get-Date -Format "o"), (Escape-Csv $drv.Letter), (Escape-Csv $dirPath), (Escape-Csv $msg)))
                $errorsOnDrive++
                $totalErrors++
            }
            if ($itemsSinceFlush -ge $flushEvery) {
                if ($folderBuffer.Count -gt 0) {
                    [System.IO.File]::AppendAllLines($folderCsv, $folderBuffer)
                    $folderBuffer.Clear()
                }
                if ($errorBuffer.Count -gt 0) {
                    [System.IO.File]::AppendAllLines($errorCsv, $errorBuffer)
                    $errorBuffer.Clear()
                }
                $itemsSinceFlush = 0
                if (((Get-Date) - $lastUiUpdate).TotalSeconds -ge 2) {
                    $lastUiUpdate = Get-Date
                    # lightweight progress refresh
                    Write-Host ("  ... folders: {0:N0}  files: {1:N0}  current: {2}" -f $totalFolders, $totalFiles, $currentFolder.Substring(0, [math]::Min(60, $currentFolder.Length)))
                }
            }
        }
    } catch {
        Write-ScanLog "Folder enum error on $($drv.Letter): $($_.Exception.Message)" "ERROR" $logFile
        $status = "Partial"
    }

    if ($folderBuffer.Count -gt 0) {
        [System.IO.File]::AppendAllLines($folderCsv, $folderBuffer)
        $folderBuffer.Clear()
    }

    if (-not $stopped) {
        try {
            foreach ($filePath in $fileEnum) {
                if (Test-Path -LiteralPath $stopFlag) { $stopped = $true; $status = "Stopped"; break }
                try {
                    $fi = New-Object System.IO.FileInfo($filePath)
                    $ext = $fi.Extension
                    $cat = Get-FileCategory $ext
                    $size = $fi.Length
                    $ctime = try { $fi.CreationTime.ToString("yyyy-MM-dd HH:mm:ss") } catch { "" }
                    $mtime = try { $fi.LastWriteTime.ToString("yyyy-MM-dd HH:mm:ss") } catch { "" }
                    $attrs = try { $fi.Attributes.ToString() } catch { "" }

                    $line = "{0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10}" -f `
                        (Escape-Csv $drv.Letter),
                        (Escape-Csv $filePath),
                        (Escape-Csv $fi.Name),
                        (Escape-Csv $ext),
                        (Escape-Csv $cat),
                        $size,
                        (Escape-Csv (Format-Size $size)),
                        (Escape-Csv $ctime),
                        (Escape-Csv $mtime),
                        (Escape-Csv $attrs),
                        "OK"
                    $fileBuffer.Add($line)

                    if ($cat -eq "Image") {
                        $pline = "{0},{1},{2},{3},{4},{5},{6},{7}" -f `
                            (Escape-Csv $drv.Letter),
                            (Escape-Csv $filePath),
                            (Escape-Csv $fi.Name),
                            (Escape-Csv $ext),
                            $size,
                            (Escape-Csv (Format-Size $size)),
                            (Escape-Csv $ctime),
                            (Escape-Csv $mtime)
                        $photoBuffer.Add($pline)
                    }

                    if (-not $catCounts.ContainsKey($cat)) { $catCounts[$cat] = 0 }
                    $catCounts[$cat]++

                    $filesOnDrive++
                    $totalFiles++
                    $totalBytes += $size
                    $itemsSinceFlush++
                } catch {
                    $msg = $_.Exception.Message
                    $errorBuffer.Add(("{0},{1},{2},{3}" -f (Get-Date -Format "o"), (Escape-Csv $drv.Letter), (Escape-Csv $filePath), (Escape-Csv $msg)))
                    $errorsOnDrive++
                    $totalErrors++
                }

                if ($itemsSinceFlush -ge $flushEvery) {
                    if ($fileBuffer.Count -gt 0)  { [System.IO.File]::AppendAllLines($fileCsv, $fileBuffer); $fileBuffer.Clear() }
                    if ($photoBuffer.Count -gt 0) { [System.IO.File]::AppendAllLines($photoCsv, $photoBuffer); $photoBuffer.Clear() }
                    if ($errorBuffer.Count -gt 0) { [System.IO.File]::AppendAllLines($errorCsv, $errorBuffer); $errorBuffer.Clear() }
                    $itemsSinceFlush = 0
                    if (((Get-Date) - $lastUiUpdate).TotalSeconds -ge 2) {
                        $lastUiUpdate = Get-Date
                        Write-Host ("  ... folders: {0:N0}  files: {1:N0}  size: {2}" -f $totalFolders, $totalFiles, (Format-Size $totalBytes))
                    }
                }
            }
        } catch {
            Write-ScanLog "File enum error on $($drv.Letter): $($_.Exception.Message)" "ERROR" $logFile
            if ($status -eq "Completed") { $status = "Partial" }
        }
    }

    # Final flush for this drive
    if ($fileBuffer.Count -gt 0)  { [System.IO.File]::AppendAllLines($fileCsv, $fileBuffer); $fileBuffer.Clear() }
    if ($photoBuffer.Count -gt 0) { [System.IO.File]::AppendAllLines($photoCsv, $photoBuffer); $photoBuffer.Clear() }
    if ($errorBuffer.Count -gt 0) { [System.IO.File]::AppendAllLines($errorCsv, $errorBuffer); $errorBuffer.Clear() }

    $drvEnd = Get-Date
    $drivesDone++

    $drvLine = "{0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11},{12}" -f `
        (Escape-Csv $drv.Letter),
        (Escape-Csv $drv.Label),
        (Escape-Csv $drv.FileSystem),
        (Escape-Csv $drv.DriveType),
        $drv.SizeBytes,
        $drv.FreeBytes,
        $drv.UsedBytes,
        $filesOnDrive,
        $foldersOnDrive,
        $errorsOnDrive,
        (Escape-Csv $status),
        $drvStart.ToString("yyyy-MM-dd HH:mm:ss"),
        $drvEnd.ToString("yyyy-MM-dd HH:mm:ss")
    Add-Content -LiteralPath $driveCsv -Value $drvLine -Encoding UTF8

    [void]$driveResults.Add([PSCustomObject]@{
        Letter = $drv.Letter; Label = $drv.Label; Status = $status
        Files = $filesOnDrive; Folders = $foldersOnDrive; Errors = $errorsOnDrive
        Size = $drv.SizeBytes; Free = $drv.FreeBytes
    })

    Write-ScanLog ("Drive {0} finished: status={1} files={2} folders={3} errors={4}" -f $drv.Letter, $status, $filesOnDrive, $foldersOnDrive, $errorsOnDrive) "INFO" $logFile

    if ($stopped) { break }
}

$scanEnd = Get-Date
$finalStatus = if ($stopped) { "Stopped" } elseif ($totalErrors -gt 0) { "CompletedWithErrors" } else { "Completed" }

# Metadata JSON
$meta = [ordered]@{
    ScanId        = $scanId
    StartTime     = $scanStart.ToString("o")
    EndTime       = $scanEnd.ToString("o")
    Status        = $finalStatus
    DrivesTargeted= @($targets | ForEach-Object { $_.Letter })
    TotalFiles    = $totalFiles
    TotalFolders  = $totalFolders
    TotalBytes    = $totalBytes
    TotalErrors   = $totalErrors
    CategoryCounts= $catCounts
    ReportFile    = $reportFile
    DataFolder    = (Get-DataPath)
}
$meta | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $metaJson -Encoding UTF8

# Human-readable report
$sb = New-Object System.Text.StringBuilder
[void]$sb.AppendLine("BACON DRIVE SCANNER - SCAN REPORT")
[void]$sb.AppendLine("=================================")
[void]$sb.AppendLine("Scan ID     : $scanId")
[void]$sb.AppendLine("Started     : $($scanStart.ToString('yyyy-MM-dd HH:mm:ss'))")
[void]$sb.AppendLine("Finished    : $($scanEnd.ToString('yyyy-MM-dd HH:mm:ss'))")
[void]$sb.AppendLine("Status      : $finalStatus")
[void]$sb.AppendLine("Computer    : $env:COMPUTERNAME")
try { [void]$sb.AppendLine("Windows     : $([System.Environment]::OSVersion.VersionString)") } catch {}
[void]$sb.AppendLine("")
[void]$sb.AppendLine("SUMMARY")
[void]$sb.AppendLine("-------")
[void]$sb.AppendLine("Drives scanned   : $drivesDone / $($targets.Count)")
[void]$sb.AppendLine("Total files      : $totalFiles")
[void]$sb.AppendLine("Total folders    : $totalFolders")
[void]$sb.AppendLine("Total data size  : $(Format-Size $totalBytes)  (sum of accessible file sizes)")
[void]$sb.AppendLine("Errors logged    : $totalErrors")
[void]$sb.AppendLine("")
[void]$sb.AppendLine("NOTE: Total data size is the sum of file sizes the scanner could read.")
[void]$sb.AppendLine("It may differ from Windows 'used space' due to system files, permissions, and filesystem overhead.")
[void]$sb.AppendLine("")
[void]$sb.AppendLine("FILE CATEGORIES")
[void]$sb.AppendLine("---------------")
foreach ($k in ($catCounts.Keys | Sort-Object)) {
    [void]$sb.AppendLine(("  {0,-15} {1,10:N0}" -f $k, $catCounts[$k]))
}
[void]$sb.AppendLine("")
[void]$sb.AppendLine("PER-DRIVE RESULTS")
[void]$sb.AppendLine("-----------------")
foreach ($r in $driveResults) {
    [void]$sb.AppendLine(("Drive {0}  [{1}]" -f $r.Letter, $r.Status))
    [void]$sb.AppendLine(("  Label    : {0}" -f $r.Label))
    [void]$sb.AppendLine(("  Capacity : {0}   Free: {1}" -f (Format-Size $r.Size), (Format-Size $r.Free)))
    [void]$sb.AppendLine(("  Files    : {0:N0}    Folders: {1:N0}    Errors: {2}" -f $r.Files, $r.Folders, $r.Errors))
    [void]$sb.AppendLine("")
}
[void]$sb.AppendLine("OUTPUT FILES")
[void]$sb.AppendLine("------------")
[void]$sb.AppendLine("Report  : $reportFile")
[void]$sb.AppendLine("Files   : $fileCsv")
[void]$sb.AppendLine("Folders : $folderCsv")
[void]$sb.AppendLine("Photos  : $photoCsv")
[void]$sb.AppendLine("Drives  : $driveCsv")
[void]$sb.AppendLine("Errors  : $errorCsv")
[void]$sb.AppendLine("Meta    : $metaJson")
[void]$sb.AppendLine("Log     : $logFile")
[void]$sb.AppendLine("")
if ($stopped) {
    [void]$sb.AppendLine("*** SCAN WAS STOPPED BY USER - RESULTS ARE PARTIAL ***")
}

$sb.ToString() | Set-Content -LiteralPath $reportFile -Encoding UTF8
Write-ScanLog "Scan finished. Status=$finalStatus Files=$totalFiles Folders=$totalFolders Errors=$totalErrors" "INFO" $logFile

# Final screen
Clear-Host
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "       SCAN FINISHED" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host ("Status     : {0}" -f $finalStatus)
Write-Host ("Files      : {0:N0}" -f $totalFiles)
Write-Host ("Folders    : {0:N0}" -f $totalFolders)
Write-Host ("Data size  : {0}" -f (Format-Size $totalBytes))
Write-Host ("Errors     : {0}" -f $totalErrors)
Write-Host ""
Write-Host "Report saved to:"
Write-Host "  $reportFile"
Write-Host ""
Write-Host "Detailed data in:"
Write-Host "  $(Get-DataPath)"
Write-Host ""
