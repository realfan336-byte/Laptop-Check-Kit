================================================================================
  BACON DRIVE SCANNER
  Full Drive Inventory, Logs & Reports
================================================================================

WHAT THIS TOOL DOES
-------------------
- Discovers all accessible local and removable drives
- Recursively inventories files and folders (metadata only)
- Classifies files (Images, Videos, Audio, Documents, Archives, Applications)
- Creates a dedicated photo inventory
- Saves human-readable reports, CSV data, and logs
- Shows real progress while scanning
- Works on low-RAM systems (designed for 4 GB+)
- NEVER deletes, moves, renames, or modifies your files


FOLDER STRUCTURE
----------------
BaconDriveScanner/
├── BaconDriveScanner.bat   <-- Double-click this to start
├── README.txt
├── Logs/                   Scan logs
├── Reports/                Human-readable text reports
├── Data/                   CSV inventories + JSON metadata
├── Config/                 Stop flag and optional settings
└── Scripts/                PowerShell engine (do not run directly)


HOW TO USE
----------
1. Extract the ZIP anywhere (Desktop, USB, etc.).
2. Double-click BaconDriveScanner.bat
3. Choose:
   1 = Scan all accessible local/removable drives
   2 = Choose specific drive letters
4. Wait for the scan to finish (large drives take time).
5. Open Reports\ for the summary, or Data\ for detailed CSVs.


STOPPING A SCAN SAFELY
----------------------
While a scan is running:
- Create an empty file named STOP_SCAN.flag inside the Config folder
  (menu option 8 does this for you)
- Or press Ctrl+C in the scanner window

The scanner will finish the current batch, save partial results,
and mark the scan as "Stopped" / incomplete.


OUTPUT FILES (each scan gets a unique timestamp)
------------------------------------------------
Reports/
  Drive_Scan_Report_YYYY-MM-DD_HHMMSS.txt   <-- main readable summary

Data/
  Drive_Summary_....csv      Per-drive totals
  File_Inventory_....csv     Every accessible file
  Folder_Inventory_....csv   Every accessible folder
  Photo_Inventory_....csv    Images only
  Scan_Errors_....csv        Paths that could not be read
  Scan_Metadata_....json     Machine-readable scan info

Logs/
  Drive_Scanner_Log_....log  Detailed activity log


SAFETY
------
- Read-only: never deletes, moves, or changes scanned files
- Does not follow the scanner's own output into other tools' data
- Does not change permissions or take ownership
- Does not format or repair drives
- Does not upload anything
- Access-denied folders are logged and skipped; scan continues
- Previous reports are never overwritten


LOW-RESOURCE DESIGN
-------------------
- Streams results to disk in small batches
- Does not load entire drive listings into RAM
- Does not compute file hashes
- Does not open or read file contents


TIPS FOR YOUR LAPTOP (4 GB RAM)
-------------------------------
- Close heavy programs before scanning large drives
- Prefer "Select Specific Drives" and scan one drive at a time if the
  system feels slow
- Photo_Inventory CSV is useful for finding where pictures are stored


TESTING CHECKLIST
-----------------
[ ] Launch BaconDriveScanner.bat - menu appears
[ ] Option 2 lists real drive letters on this PC
[ ] Option 1 or 2 completes and creates files in Reports, Data, Logs
[ ] Report shows file/folder counts and categories
[ ] Photo_Inventory contains image paths if any images exist
[ ] Creating Config\STOP_SCAN.flag during a scan stops it and saves partial data
[ ] Old reports remain after a new scan
[ ] No files on scanned drives were modified


REQUIREMENTS
------------
- Windows 10 or 11
- PowerShell (built into Windows)
- Write permission in the folder where you extracted the scanner

================================================================================
