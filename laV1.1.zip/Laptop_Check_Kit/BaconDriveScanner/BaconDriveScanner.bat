@echo off
setlocal EnableDelayedExpansion
title Bacon Drive Scanner
color 0B

set "ROOT=%~dp0"
if "%ROOT:~-1%"=="\" set "ROOT=%ROOT:~0,-1%"
set "SCRIPTS=%ROOT%\Scripts"
set "PS=powershell.exe -NoProfile -ExecutionPolicy Bypass -File"

if not exist "%ROOT%\Logs"    mkdir "%ROOT%\Logs"    >nul 2>&1
if not exist "%ROOT%\Reports" mkdir "%ROOT%\Reports" >nul 2>&1
if not exist "%ROOT%\Data"    mkdir "%ROOT%\Data"    >nul 2>&1
if not exist "%ROOT%\Config"  mkdir "%ROOT%\Config"  >nul 2>&1

if not exist "%SCRIPTS%\ScanCore.ps1" (
    echo [ERROR] ScanCore.ps1 missing. Re-extract the full ZIP.
    pause
    exit /b 1
)

:MENU
cls
echo ============================================================
echo          BACON DRIVE SCANNER
echo ============================================================
echo.
echo   Project folder:
echo   %ROOT%
echo.
echo   1. Scan All Accessible Drives
echo   2. Select Specific Drives
echo   3. View Latest Scan Summary
echo   4. Open Reports Folder
echo   5. Open Data Folder
echo   6. Open Logs Folder
echo   7. View Previous Scan List
echo   8. Stop Current Scan Safely
echo   9. Exit
echo.
echo ============================================================
set /p "OPT=Choose an option [1-9]: "

if "%OPT%"=="1" goto :SCANALL
if "%OPT%"=="2" goto :SCANSEL
if "%OPT%"=="3" goto :LATEST
if "%OPT%"=="4" goto :OPENREP
if "%OPT%"=="5" goto :OPENDATA
if "%OPT%"=="6" goto :OPENLOG
if "%OPT%"=="7" goto :PREV
if "%OPT%"=="8" goto :STOP
if "%OPT%"=="9" goto :EXIT
echo Invalid option.
timeout /t 1 >nul
goto :MENU

:SCANALL
cls
echo Starting full scan of all accessible local/removable drives...
echo This can take a long time on large drives.
echo.
echo To stop safely while scanning:
echo   - Create an empty file named STOP_SCAN.flag in the Config folder
echo   - Or press Ctrl+C in this window
echo.
pause
%PS% "%SCRIPTS%\ScanCore.ps1"
echo.
pause
goto :MENU

:SCANSEL
cls
echo Discovering drives...
echo.
%PS% "%SCRIPTS%\ScanCore.ps1" -ListOnly
echo.
echo Enter drive letters separated by spaces (example: C: D: E:)
echo Or type CANCEL
set /p "DRIVES=Drives: "
if /i "%DRIVES%"=="CANCEL" goto :MENU
if "%DRIVES%"=="" goto :MENU
echo.
echo You selected: %DRIVES%
echo Type YES to start scanning these drives.
set /p "CONF= "
if /i not "%CONF%"=="YES" (
    echo Cancelled.
    pause
    goto :MENU
)
REM Build -DriveLetters args
set "ARGS="
for %%D in (%DRIVES%) do (
    set "ARGS=!ARGS! -DriveLetters %%D"
)
%PS% "%SCRIPTS%\ScanCore.ps1" !ARGS!
echo.
pause
goto :MENU

:LATEST
cls
echo Latest report:
echo.
for /f "delims=" %%F in ('dir /b /o-d "%ROOT%\Reports\Drive_Scan_Report_*.txt" 2^>nul') do (
    echo %%F
    echo.
    type "%ROOT%\Reports\%%F"
    echo.
    goto :LATESTDONE
)
echo No reports found yet. Run a scan first.
:LATESTDONE
echo.
pause
goto :MENU

:OPENREP
if not exist "%ROOT%\Reports" mkdir "%ROOT%\Reports"
start "" explorer "%ROOT%\Reports"
goto :MENU

:OPENDATA
if not exist "%ROOT%\Data" mkdir "%ROOT%\Data"
start "" explorer "%ROOT%\Data"
goto :MENU

:OPENLOG
if not exist "%ROOT%\Logs" mkdir "%ROOT%\Logs"
start "" explorer "%ROOT%\Logs"
goto :MENU

:PREV
cls
echo Previous scan reports:
echo.
dir /b /o-d "%ROOT%\Reports\Drive_Scan_Report_*.txt" 2>nul
if errorlevel 1 echo No previous reports.
echo.
echo Previous data files:
dir /b /o-d "%ROOT%\Data\Scan_Metadata_*.json" 2>nul
if errorlevel 1 echo No previous metadata.
echo.
pause
goto :MENU

:STOP
cls
echo Creating stop flag...
echo. > "%ROOT%\Config\STOP_SCAN.flag"
echo.
echo STOP_SCAN.flag has been created in Config\
echo If a scan is running, it will stop after the current batch
echo and save partial results.
echo.
echo (If no scan is running, this does nothing harmful.)
echo.
pause
goto :MENU

:EXIT
echo Exiting.
timeout /t 1 >nul
exit /b 0
