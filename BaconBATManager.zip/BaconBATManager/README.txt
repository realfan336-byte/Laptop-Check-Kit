================================================================================
  BACON BAT MANAGER
  Windows BAT Cleanup & Recovery Tool
================================================================================

WHAT THIS TOOL DOES
-------------------
- Scans the folder where BaconBATManager.bat lives (and its subfolders)
  for .bat files.
- Lets you move selected BAT files into a managed "Bin" folder.
- Keeps each moved file recoverable for 24 hours.
- After 24 hours the file is permanently deleted (on next cleanup).
- You can restore a file or permanently delete it early.
- Optional background cleanup via Windows Task Scheduler.

It never runs the BAT files it finds. It only moves / restores / deletes
them under your control.


FOLDER STRUCTURE
----------------
BaconBATManager/
├── BaconBATManager.bat      <-- Main launcher (double-click this)
├── README.txt               <-- This file
├── Bin/                     <-- Files waiting for expiration (created automatically)
├── Data/                    <-- Metadata index (created automatically)
├── Logs/                    <-- Daily log files (created automatically)
└── Scripts/                 <-- Supporting PowerShell scripts
    ├── Common.ps1
    ├── ScanBats.ps1
    ├── MoveToBin.ps1
    ├── ListBin.ps1
    ├── Restore.ps1
    ├── PermanentDelete.ps1
    ├── CleanupExpired.ps1
    └── SetupBackground.ps1


HOW TO START
------------
1. Extract the entire ZIP to any normal folder (Desktop, Documents, USB…).
2. Open the BaconBATManager folder.
3. Double-click BaconBATManager.bat
4. Use the numbered menu.


MAIN MENU OPTIONS
-----------------
1. Scan for BAT Files
   Lists every .bat file under the project folder (except the manager
   itself and the Bin/Data/Logs/Scripts folders).

2. Move Selected Files to Bin
   Shows the scan, then asks for the numbers of the files you want to
   move (or type ALL). Asks for YES confirmation before moving.
   Files are stored in Bin with a 24-hour recovery period.

3. Open Bin / Restore Files
   Shows everything currently in the Bin with remaining time.
   - R = Restore selected files to their original locations
   - D = Permanently delete selected files (asks for YES)
   - E = Empty the entire Bin (asks for YES)
   - B = Back

4. Permanently Delete Selected Files
   Shortcut that opens the Bin screen.

5. Run Expired Cleanup Now
   Immediately permanently deletes any items whose 24-hour period has ended.

6. Enable / Disable Automatic Cleanup
   Creates or removes a Windows scheduled task named
   "BaconBATManager_Cleanup" that runs about once per hour.
   The task only calls this tool’s own cleanup script.
   Administrator rights are usually required to create/remove the task.
   If the task is not installed, expired files are still cleaned when
   you open the manager or choose option 5.

7. View Cleanup Log
   Shows the most recent log file.

8. Refresh Status
   Shows how many items are in the Bin, how many are still recoverable,
   how many are expired, and whether the background task exists.

9. Exit


24-HOUR TIMER
-------------
When a file is moved to the Bin the exact move time and the exact
expiration time (move time + 24 hours) are stored in Data\bin_index.json.

Closing the program or restarting Windows does NOT reset the timer.
The next time the manager runs (or the scheduled task runs) it recalculates
remaining time from the stored timestamps and deletes only what is past
expiration.

If the computer is powered off, cleanup simply waits until it is running
again.


SAFETY RULES BUILT IN
---------------------
- Only .bat files under the project folder can be moved.
- The manager’s own files and the Bin/Data/Logs/Scripts folders are
  never treated as ordinary targets.
- Permanent deletion only works on files that are inside this tool’s
  Bin folder and that have a matching metadata entry.
- Restore never overwrites an existing file at the original location.
- Confirmations are required before moving or permanently deleting.
- No system folders, Windows Recycle Bin, or unrelated drives are touched.


UNINSTALL / REMOVE
------------------
1. Open the manager → option 6 → Disable automatic cleanup
   (removes the scheduled task).
2. Restore any files you still want (option 3).
3. Delete the entire BaconBATManager folder.

That completely removes the tool and its data.


TEST CHECKLIST (manual)
-----------------------
[ ] Place a few harmless test .bat files in the project folder and in a
    subfolder.
[ ] Run Scan – they should appear; BaconBATManager.bat itself should not.
[ ] Move one or two files to Bin – they disappear from the original place
    and appear in the Bin list with ~24 h remaining.
[ ] Restore one file – it returns to the original location and leaves the Bin.
[ ] Move a file again, then use Permanent Delete – it is gone and cannot
    be restored.
[ ] Close and reopen the manager – timers still show correct remaining time.
[ ] (Optional) Enable background task (may need Run as administrator).
[ ] Check Logs folder for activity entries.


NOTES
-----
- Requires Windows 10 or 11 and PowerShell (built-in).
- For best results with the scheduled task, run the Enable option while
  the manager is elevated (right-click → Run as administrator).
- Production expiration is always 24 hours. There is no hidden short timer
  in normal use.

================================================================================
