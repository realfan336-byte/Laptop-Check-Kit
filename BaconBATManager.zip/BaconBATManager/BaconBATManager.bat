@echo off
setlocal EnableDelayedExpansion
title Bacon BAT Manager
color 0B

REM ============================================================
REM  Bacon BAT Manager - Main Launcher (fixed PowerShell calls)
REM ============================================================

set "ROOT=%~dp0"
if "%ROOT:~-1%"=="\" set "ROOT=%ROOT:~0,-1%"
set "SCRIPTS=%ROOT%\Scripts"

REM Two helpers: one for -File, one for -Command
set "PSFILE=powershell.exe -NoProfile -ExecutionPolicy Bypass -File"
set "PSCMD=powershell.exe -NoProfile -ExecutionPolicy Bypass -Command"

REM Ensure folders exist
if not exist "%ROOT%\Bin"   mkdir "%ROOT%\Bin"   >nul 2>&1
if not exist "%ROOT%\Data"  mkdir "%ROOT%\Data"  >nul 2>&1
if not exist "%ROOT%\Logs"  mkdir "%ROOT%\Logs"  >nul 2>&1

if not exist "%SCRIPTS%\Common.ps1" (
    echo [ERROR] Required file missing: Scripts\Common.ps1
    echo Please re-extract the complete package.
    pause
    exit /b 1
)

:MENU
cls
echo ============================================================
echo          BACON BAT MANAGER
echo ============================================================
echo.
echo   Project folder:
echo   %ROOT%
echo.
echo   1. Scan for BAT Files
echo   2. Move Selected Files to Bin
echo   3. Open Bin / Restore Files
echo   4. Permanently Delete Selected Files
echo   5. Run Expired Cleanup Now
echo   6. Enable / Disable Automatic Cleanup
echo   7. View Cleanup Log
echo   8. Refresh Status
echo   9. Resync Bin (fix count mismatch)
echo  10. Exit
echo.
echo ============================================================
set /p "OPT=Enter option [1-10]: "

if "%OPT%"=="1"  goto :SCAN
if "%OPT%"=="2"  goto :MOVE
if "%OPT%"=="3"  goto :BIN
if "%OPT%"=="4"  goto :PERMDEL
if "%OPT%"=="5"  goto :CLEANNOW
if "%OPT%"=="6"  goto :BACKGROUND
if "%OPT%"=="7"  goto :VIEWLOG
if "%OPT%"=="8"  goto :STATUS
if "%OPT%"=="9"  goto :RESYNC
if "%OPT%"=="10" goto :EXIT
echo Invalid option.
timeout /t 1 >nul
goto :MENU

:SCAN
cls
echo Running scan...
echo.
%PSFILE% "%SCRIPTS%\ScanBats.ps1"
echo.
pause
goto :MENU

:MOVE
cls
echo ============================================================
echo   MOVE FILES TO BIN
echo ============================================================
echo.
echo Scanning...
echo.

REM Save clean JSON for later selection (-Quiet = JSON only)
%PSFILE% "%SCRIPTS%\ScanBats.ps1" -Quiet > "%TEMP%\bacon_scan.json" 2>nul

REM Show human-readable list
%PSFILE% "%SCRIPTS%\ScanBats.ps1"
echo.
set /p "SEL=Enter numbers (space separated) or ALL or CANCEL: "
if /i "%SEL%"=="CANCEL" goto :MENU
if /i "%SEL%"=="" goto :MENU

echo.
echo Confirm: Move the selected file(s) to Bin for 24-hour recovery?
echo Type YES to continue.
set /p "CONF= "
if /i not "%CONF%"=="YES" (
    echo Cancelled.
    pause
    goto :MENU
)

echo.
echo Moving files...
echo.

REM Use -Command correctly (not mixed with -File)
%PSCMD% "& { $ErrorActionPreference='Stop'; $json = Get-Content -LiteralPath '%TEMP%\bacon_scan.json' -Raw -ErrorAction SilentlyContinue | ConvertFrom-Json; if ($null -eq $json) { $json = @() }; if ($json -isnot [System.Array]) { $json = @($json) }; $sel = '%SEL%'.Trim(); $paths = @(); if ($sel -eq 'ALL') { $paths = @($json | ForEach-Object { $_.FullName }) } else { $nums = $sel -split '\s+' | Where-Object { $_ -match '^\d+$' }; foreach ($n in $nums) { $i = [int]$n - 1; if ($i -ge 0 -and $i -lt $json.Count) { $paths += $json[$i].FullName } } }; if ($paths.Count -eq 0) { Write-Host 'No valid selection.' -ForegroundColor Yellow; exit 1 }; & '%SCRIPTS%\MoveToBin.ps1' -Paths $paths -ExpireHours 24 }"

echo.
pause
goto :MENU

:BIN
cls
echo ============================================================
echo   BIN / RECOVERY
echo ============================================================
echo.
%PSFILE% "%SCRIPTS%\ListBin.ps1" -Quiet > "%TEMP%\bacon_bin.json" 2>nul
%PSFILE% "%SCRIPTS%\ListBin.ps1"
echo.
echo Options:
echo   R  = Restore a file   (then type its NUMBER, e.g. 1)
echo   D  = Delete a file permanently (then type its NUMBER)
echo   E  = Empty entire Bin (permanent)
echo   B  = Back to main menu
echo.
set /p "BINOPT=Choice [R/D/E/B]: "

if /i "%BINOPT%"=="B" goto :MENU
if /i "%BINOPT%"=="" goto :MENU

if /i "%BINOPT%"=="E" (
    echo.
    echo WARNING: This will permanently delete EVERY file in the Bin.
    echo Type YES to confirm.
    set /p "ECONF= "
    if /i "!ECONF!"=="YES" (
        %PSFILE% "%SCRIPTS%\PermanentDelete.ps1" -All
    ) else (
        echo Cancelled.
    )
    pause
    goto :BIN
)

if /i "%BINOPT%"=="R" (
    echo.
    echo Type the NUMBER of the file you want to restore.
    echo Example: if the list shows "1. Sample_Test1.bat" then type: 1
    echo.
    set /p "RSEL=Number(s) to restore: "
    if "!RSEL!"=="" (
        echo No number entered.
        pause
        goto :BIN
    )
    %PSCMD% "& { $json = Get-Content -LiteralPath '%TEMP%\bacon_bin.json' -Raw -ErrorAction SilentlyContinue | ConvertFrom-Json; if ($null -eq $json) { $json = @() }; if ($json -isnot [System.Array]) { $json = @($json) }; $nums = '%RSEL%' -split '\s+' | Where-Object { $_ -match '^\d+$' }; $ids = @(); foreach ($n in $nums) { $i = [int]$n - 1; if ($i -ge 0 -and $i -lt $json.Count) { $ids += $json[$i].Id } }; if ($ids.Count -eq 0) { Write-Host 'No valid number. Type the number shown in the list (e.g. 1).' -ForegroundColor Yellow; exit 1 }; & '%SCRIPTS%\Restore.ps1' -Ids $ids }"
    pause
    goto :BIN
)

if /i "%BINOPT%"=="D" (
    echo.
    echo Type the NUMBER of the file you want to permanently delete.
    echo Example: if the list shows "1. Sample_Test1.bat" then type: 1
    echo.
    set /p "DSEL=Number(s) to delete: "
    if "!DSEL!"=="" (
        echo No number entered.
        pause
        goto :BIN
    )
    echo Type YES to confirm permanent deletion.
    set /p "DCONF= "
    if /i "!DCONF!"=="YES" (
        %PSCMD% "& { $json = Get-Content -LiteralPath '%TEMP%\bacon_bin.json' -Raw -ErrorAction SilentlyContinue | ConvertFrom-Json; if ($null -eq $json) { $json = @() }; if ($json -isnot [System.Array]) { $json = @($json) }; $nums = '%DSEL%' -split '\s+' | Where-Object { $_ -match '^\d+$' }; $ids = @(); foreach ($n in $nums) { $i = [int]$n - 1; if ($i -ge 0 -and $i -lt $json.Count) { $ids += $json[$i].Id } }; if ($ids.Count -eq 0) { Write-Host 'No valid number. Type the number shown in the list (e.g. 1).' -ForegroundColor Yellow; exit 1 }; & '%SCRIPTS%\PermanentDelete.ps1' -Ids $ids }"
    ) else (
        echo Cancelled.
    )
    pause
    goto :BIN
)

echo Unknown choice. Use R, D, E or B.
timeout /t 2 >nul
goto :BIN

:PERMDEL
cls
echo This option opens the Bin screen where you can delete permanently.
timeout /t 1 >nul
goto :BIN

:CLEANNOW
cls
echo Running expired-item cleanup now...
echo.
%PSFILE% "%SCRIPTS%\CleanupExpired.ps1"
echo.
pause
goto :MENU

:BACKGROUND
cls
echo ============================================================
echo   AUTOMATIC CLEANUP
echo ============================================================
echo.
echo   1. Show status
echo   2. Enable automatic cleanup (creates scheduled task)
echo   3. Disable automatic cleanup (removes scheduled task)
echo   4. Back
echo.
set /p "BG=Choice: "
if "%BG%"=="1" %PSFILE% "%SCRIPTS%\SetupBackground.ps1" -Action Status
if "%BG%"=="2" %PSFILE% "%SCRIPTS%\SetupBackground.ps1" -Action Enable
if "%BG%"=="3" %PSFILE% "%SCRIPTS%\SetupBackground.ps1" -Action Disable
if "%BG%"=="4" goto :MENU
echo.
pause
goto :BACKGROUND

:VIEWLOG
cls
echo Recent log entries:
echo.
if exist "%ROOT%\Logs" (
    for /f "delims=" %%F in ('dir /b /o-d "%ROOT%\Logs\*.log" 2^>nul') do (
        echo ---- %%F ----
        type "%ROOT%\Logs\%%F"
        echo.
        goto :LOGDONE
    )
    echo No log files yet.
) else (
    echo Logs folder not found.
)
:LOGDONE
echo.
pause
goto :MENU

:STATUS
cls
echo ============================================================
echo   STATUS
echo ============================================================
echo.
echo Project : %ROOT%
echo.
%PSCMD% "& { . '%SCRIPTS%\Common.ps1'; Ensure-Folders; $idx = Load-Index; $now = Get-Date; $pending = 0; $expired = 0; foreach ($e in $idx) { $exp = [datetime]::Parse($e.ExpireTime); if ($now -ge $exp) { $expired++ } else { $pending++ } }; Write-Host ('Files currently in Bin : {0}' -f $idx.Count); Write-Host ('  Still recoverable   : {0}' -f $pending); Write-Host ('  Expired             : {0}' -f $expired); Write-Host ''; $t = Get-ScheduledTask -TaskName 'BaconBATManager_Cleanup' -ErrorAction SilentlyContinue; if ($t) { Write-Host ('Automatic cleanup     : ' + $t.State) } else { Write-Host 'Automatic cleanup     : Not turned on' } }"
echo.
pause
goto :MENU

:RESYNC
cls
echo Running Bin resync (fixes count mismatch)...
echo.
%PSFILE% "%SCRIPTS%\ResyncBin.ps1"
echo.
pause
goto :MENU

:EXIT
echo.
echo Exiting Bacon BAT Manager.
timeout /t 1 >nul
exit /b 0
