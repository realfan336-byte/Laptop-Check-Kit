@echo off
echo Sample BAT inside a subfolder - for testing nested detection.
pause
