# ScanBats.ps1 - Find .bat files under the manager root (excluding protected folders)
param(
    [switch]$Quiet
)

. "$PSScriptRoot\Common.ps1"
Ensure-Folders

$root = Get-ManagerRoot
$excludeNames = @(
    "BaconBATManager.bat",
    "Bin",
    "Data",
    "Logs",
    "Scripts"
)

$found = @()

try {
    $all = Get-ChildItem -LiteralPath $root -Filter "*.bat" -Recurse -File -ErrorAction SilentlyContinue
    foreach ($f in $all) {
        $rel = Get-RelativePath -FullPath $f.FullName -BasePath $root
        $top = $rel.Split('\')[0]

        # Skip own launcher and anything under protected folders
        if ($f.Name -eq "BaconBATManager.bat") { continue }
        if ($excludeNames -contains $top) { continue }
        if ($rel -like "Scripts\*") { continue }
        if ($rel -like "Bin\*") { continue }
        if ($rel -like "Data\*") { continue }
        if ($rel -like "Logs\*") { continue }

        $found += [PSCustomObject]@{
            FullName     = $f.FullName
            Name         = $f.Name
            RelativePath = $rel
            Directory    = $f.DirectoryName
            SizeBytes    = $f.Length
            LastWrite    = $f.LastWriteTime
        }
    }
}
catch {
    Write-Log "Scan error: $_" "ERROR"
    if (-not $Quiet) { Write-Host "Scan error: $_" -ForegroundColor Red }
}

if (-not $Quiet) {
    Write-Host ""
    Write-Host "============================================================" -ForegroundColor Cyan
    Write-Host "  SCAN RESULTS" -ForegroundColor Cyan
    Write-Host "============================================================" -ForegroundColor Cyan
    Write-Host "Root: $root"
    Write-Host ("Found {0} BAT file(s) (manager files excluded)" -f $found.Count) -ForegroundColor Green
    Write-Host ""

    if ($found.Count -eq 0) {
        Write-Host "No BAT files found in the project folder or its subfolders." -ForegroundColor Yellow
    }
    else {
        $i = 1
        foreach ($item in $found) {
            Write-Host ("  {0,3}. {1}" -f $i, $item.RelativePath)
            $i++
        }
    }
    Write-Host ""
}

# JSON only when -Quiet is used (so the BAT can capture a clean list)
if ($Quiet) {
    $found | ConvertTo-Json -Depth 4
}
