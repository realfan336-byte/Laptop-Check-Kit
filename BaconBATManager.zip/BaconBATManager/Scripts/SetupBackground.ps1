# SetupBackground.ps1 - Create or remove a scheduled task for automatic cleanup
param(
    [ValidateSet("Enable","Disable","Status")]
    [string]$Action = "Status"
)

. "$PSScriptRoot\Common.ps1"
Ensure-Folders

$taskName = "BaconBATManager_Cleanup"
$scriptPath = Join-Path $PSScriptRoot "CleanupExpired.ps1"
$root = Get-ManagerRoot

function Get-TaskStatus {
    try {
        $t = Get-ScheduledTask -TaskName $taskName -ErrorAction Stop
        return $t.State.ToString()
    }
    catch {
        return "NotInstalled"
    }
}

$current = Get-TaskStatus

Write-Host ""
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "  AUTOMATIC CLEANUP (Task Scheduler)" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "Task name : $taskName"
Write-Host "Current   : $current"
Write-Host ""

if ($Action -eq "Status") {
    if ($current -eq "NotInstalled") {
        Write-Host "Automatic cleanup is NOT installed."
        Write-Host "Expired files will still be removed when you open the manager."
    }
    else {
        Write-Host "Automatic cleanup is installed and state is: $current"
        Write-Host "The task runs hourly and only deletes items past their 24-hour mark."
    }
    Write-Host ""
    return
}

if ($Action -eq "Disable") {
    if ($current -eq "NotInstalled") {
        Write-Host "Nothing to remove."
        return
    }
    try {
        Unregister-ScheduledTask -TaskName $taskName -Confirm:$false -ErrorAction Stop
        Write-Host "Scheduled task removed." -ForegroundColor Green
        Write-Log "Background task disabled"
    }
    catch {
        Write-Host "Failed to remove task: $_" -ForegroundColor Red
        Write-Host "You may need to run this script as Administrator."
        Write-Log "Failed to disable task: $_" "ERROR"
    }
    return
}

if ($Action -eq "Enable") {
    if ($current -ne "NotInstalled") {
        Write-Host "Task already exists (state: $current). Remove it first if you want to recreate."
        return
    }

    Write-Host "This will create a Windows scheduled task that runs every hour."
    Write-Host "The task only calls CleanupExpired.ps1 for THIS manager."
    Write-Host "It does not modify security settings or install a service."
    Write-Host ""
    Write-Host "Administrator rights are usually required to create scheduled tasks."
    Write-Host ""

    $arg = "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$scriptPath`" -Silent"
    $action  = New-ScheduledTaskAction -Execute "powershell.exe" -Argument $arg
    $trigger = New-ScheduledTaskTrigger -Once -At (Get-Date).Date -RepetitionInterval (New-TimeSpan -Hours 1) -RepetitionDuration ([TimeSpan]::MaxValue)
    $settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable -ExecutionTimeLimit (New-TimeSpan -Minutes 10)

    try {
        Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger -Settings $settings -Description "Bacon BAT Manager - delete expired Bin items after 24 hours" -Force | Out-Null
        Write-Host "Scheduled task created successfully." -ForegroundColor Green
        Write-Host "It will run approximately every hour while the computer is on."
        Write-Log "Background task enabled"
    }
    catch {
        Write-Host "Failed to create task: $_" -ForegroundColor Red
        Write-Host "Try running the manager as Administrator and choose Enable again."
        Write-Log "Failed to enable task: $_" "ERROR"
    }
}
