# PermanentDelete.ps1 - Permanently delete selected (or expired) items from Bin
param(
    [string[]]$Ids,                 # Specific Ids to delete
    [switch]$ExpiredOnly,           # Delete only items past ExpireTime
    [switch]$All,                   # Delete everything in Bin (requires confirmation upstream)
    [switch]$Force
)

. "$PSScriptRoot\Common.ps1"
Ensure-Folders

$index = Load-Index
$bin   = Get-BinPath
$now   = Get-Date
$results = @()
$keep = @()

foreach ($e in $index) {
    $shouldDelete = $false

    if ($All) {
        $shouldDelete = $true
    }
    elseif ($ExpiredOnly) {
        $expire = [datetime]::Parse($e.ExpireTime)
        if ($now -ge $expire) { $shouldDelete = $true }
    }
    elseif ($Ids -and ($Ids -contains $e.Id)) {
        $shouldDelete = $true
    }

    if (-not $shouldDelete) {
        $keep += $e
        continue
    }

    $obj = [PSCustomObject]@{
        Id      = $e.Id
        Name    = $e.OriginalName
        Success = $false
        Message = ""
    }

    $stored = Join-Path $bin $e.StoredName

    # Critical safety: only delete if the file is inside our Bin folder
    if (-not $stored.StartsWith($bin, [StringComparison]::OrdinalIgnoreCase)) {
        $obj.Message = "Safety block: path is not inside Bin"
        $results += $obj
        $keep += $e
        Write-Log "Safety block on delete: $stored" "ERROR"
        continue
    }

    try {
        if (Test-Path -LiteralPath $stored) {
            Remove-Item -LiteralPath $stored -Force -ErrorAction Stop
            $obj.Success = $true
            $obj.Message = "Permanently deleted"
            Write-Log "Permanently deleted: $($e.OriginalName) ($($e.StoredName))"
        }
        else {
            $obj.Success = $true
            $obj.Message = "File already missing - index entry removed"
            Write-Log "Index cleanup (file missing): $($e.OriginalName)"
        }
    }
    catch {
        $obj.Message = "Delete failed: $($_.Exception.Message)"
        Write-Log "Permanent delete failed for $($e.OriginalName): $_" "ERROR"
        $keep += $e
    }

    $results += $obj
}

Save-Index -Items $keep

Write-Host ""
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "  PERMANENT DELETE RESULTS" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
if ($results.Count -eq 0) {
    Write-Host "Nothing to delete." -ForegroundColor Yellow
}
else {
    foreach ($r in $results) {
        if ($r.Success) {
            Write-Host ("[OK]   {0} - {1}" -f $r.Name, $r.Message) -ForegroundColor Green
        }
        else {
            Write-Host ("[FAIL] {0} - {1}" -f $r.Name, $r.Message) -ForegroundColor Red
        }
    }
}
Write-Host ""

$results | ConvertTo-Json -Depth 4
