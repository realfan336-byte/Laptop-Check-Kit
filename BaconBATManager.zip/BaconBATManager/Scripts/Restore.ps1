# Restore.ps1 - Restore selected items from Bin to their original locations
param(
    [Parameter(Mandatory=$true)]
    [string[]]$Ids          # Entry Ids from the index
)

. "$PSScriptRoot\Common.ps1"
Ensure-Folders

$index  = Load-Index
$bin    = Get-BinPath
$results = @()
$newIndex = @()

# Build lookup
$lookup = @{}
foreach ($e in $index) { $lookup[$e.Id] = $e }

foreach ($id in $Ids) {
    $obj = [PSCustomObject]@{
        Id      = $id
        Success = $false
        Message = ""
    }

    if (-not $lookup.ContainsKey($id)) {
        $obj.Message = "Id not found in index"
        $results += $obj
        continue
    }

    $entry = $lookup[$id]
    $stored = Join-Path $bin $entry.StoredName

    try {
        if (-not (Test-Path -LiteralPath $stored)) {
            $obj.Message = "Stored file missing from Bin"
            $results += $obj
            continue
        }

        $destDir = $entry.OriginalDir
        $destFile = Join-Path $destDir $entry.OriginalName

        # Safety: destination must still be under manager root
        if (-not (Test-IsInsideManager -FullPath $destDir)) {
            $obj.Message = "Original location is outside project - restore blocked"
            $results += $obj
            continue
        }

        if (-not (Test-Path -LiteralPath $destDir)) {
            New-Item -ItemType Directory -Path $destDir -Force | Out-Null
        }

        if (Test-Path -LiteralPath $destFile) {
            $obj.Message = "A file with the same name already exists at original location. Restore cancelled to avoid overwrite."
            $results += $obj
            # Keep the entry in index
            $newIndex += $entry
            continue
        }

        Move-Item -LiteralPath $stored -Destination $destFile -ErrorAction Stop
        $obj.Success = $true
        $obj.Message = "Restored to $($entry.OriginalRelative)"
        Write-Log "Restored: $($entry.OriginalRelative)"
        # Do NOT add back to newIndex (removes from Bin tracking)
    }
    catch {
        $obj.Message = "Restore failed: $($_.Exception.Message)"
        Write-Log "Restore failed for $id : $_" "ERROR"
        $newIndex += $entry   # keep it
    }

    $results += $obj
}

# Keep entries that were not successfully restored
foreach ($e in $index) {
    if ($Ids -notcontains $e.Id) {
        $newIndex += $e
    }
    else {
        # already handled above
        $match = $results | Where-Object { $_.Id -eq $e.Id }
        if ($match -and -not $match.Success) {
            # already added in the failure path
        }
    }
}

# Rebuild cleanly
$final = @()
foreach ($e in $index) {
    $r = $results | Where-Object { $_.Id -eq $e.Id }
    if ($null -eq $r -or -not $r.Success) {
        $final += $e
    }
}
Save-Index -Items $final

Write-Host ""
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "  RESTORE RESULTS" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
foreach ($r in $results) {
    if ($r.Success) {
        Write-Host ("[OK]   {0}" -f $r.Message) -ForegroundColor Green
    }
    else {
        Write-Host ("[FAIL] {0} - {1}" -f $r.Id, $r.Message) -ForegroundColor Red
    }
}
Write-Host ""

$results | ConvertTo-Json -Depth 4
