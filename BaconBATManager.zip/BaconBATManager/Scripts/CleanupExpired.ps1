# CleanupExpired.ps1 - Delete only items that have passed their ExpireTime
# This is the script used by both the main menu and the scheduled task.

param(
    [switch]$Silent
)

. "$PSScriptRoot\Common.ps1"
Ensure-Folders

# Simple lock to prevent concurrent runs
$lockFile = Join-Path (Get-DataPath) "cleanup.lock"
if (Test-Path -LiteralPath $lockFile) {
    $age = (Get-Date) - (Get-Item -LiteralPath $lockFile).LastWriteTime
    if ($age.TotalMinutes -lt 10) {
        if (-not $Silent) { Write-Host "Cleanup already running or recently finished. Skipping." -ForegroundColor Yellow }
        Write-Log "Cleanup skipped - lock present" "INFO"
        exit 0
    }
    # Stale lock - remove it
    Remove-Item -LiteralPath $lockFile -Force -ErrorAction SilentlyContinue
}

try {
    "locked" | Set-Content -LiteralPath $lockFile -Encoding ASCII

    if (-not $Silent) {
        Write-Host "Running expired-item cleanup..." -ForegroundColor Cyan
    }
    Write-Log "Cleanup started"

    # Call the permanent delete logic for expired items only
    & "$PSScriptRoot\PermanentDelete.ps1" -ExpiredOnly

    Write-Log "Cleanup finished"
}
finally {
    if (Test-Path -LiteralPath $lockFile) {
        Remove-Item -LiteralPath $lockFile -Force -ErrorAction SilentlyContinue
    }
}
