# Common.ps1 - Shared functions for Bacon BAT Manager
# Do not run this file directly.

$ErrorActionPreference = "Stop"

function Get-ManagerRoot {
    # Scripts folder is one level below root
    $scriptDir = $PSScriptRoot
    if (-not $scriptDir) { $scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path }
    return (Resolve-Path (Join-Path $scriptDir "..")).Path
}

function Get-BinPath {
    return (Join-Path (Get-ManagerRoot) "Bin")
}

function Get-DataPath {
    return (Join-Path (Get-ManagerRoot) "Data")
}

function Get-LogsPath {
    return (Join-Path (Get-ManagerRoot) "Logs")
}

function Ensure-Folders {
    $folders = @(
        (Get-BinPath),
        (Get-DataPath),
        (Get-LogsPath)
    )
    foreach ($f in $folders) {
        if (-not (Test-Path -LiteralPath $f)) {
            New-Item -ItemType Directory -Path $f -Force | Out-Null
        }
    }
}

function Write-Log {
    param([string]$Message, [string]$Level = "INFO")
    Ensure-Folders
    $logFile = Join-Path (Get-LogsPath) ("Manager_" + (Get-Date -Format "yyyy-MM-dd") + ".log")
    $line = "{0} [{1}] {2}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $Level, $Message
    Add-Content -LiteralPath $logFile -Value $line -Encoding UTF8
}

function Get-IndexPath {
    return (Join-Path (Get-DataPath) "bin_index.json")
}

function Load-Index {
    $path = Get-IndexPath
    if (-not (Test-Path -LiteralPath $path)) {
        return @()
    }
    try {
        $raw = Get-Content -LiteralPath $path -Raw -Encoding UTF8
        if ([string]::IsNullOrWhiteSpace($raw)) { return @() }
        $data = $raw | ConvertFrom-Json
        if ($data -is [System.Array]) { return @($data) }
        if ($null -eq $data) { return @() }
        return @($data)
    }
    catch {
        Write-Log "Failed to load index: $_" "ERROR"
        return @()
    }
}

function Save-Index {
    param([array]$Items)
    Ensure-Folders
    $path = Get-IndexPath
    $Items | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $path -Encoding UTF8
}

function Test-IsInsideManager {
    param([string]$FullPath)
    $root = (Get-ManagerRoot).TrimEnd('\')
    $full = $FullPath.TrimEnd('\')
    return $full.StartsWith($root, [StringComparison]::OrdinalIgnoreCase)
}

function Get-RelativePath {
    param([string]$FullPath, [string]$BasePath)
    $base = $BasePath.TrimEnd('\') + '\'
    if ($FullPath.StartsWith($base, [StringComparison]::OrdinalIgnoreCase)) {
        return $FullPath.Substring($base.Length)
    }
    return $FullPath
}

function New-GuidName {
    return [guid]::NewGuid().ToString("N")
}
