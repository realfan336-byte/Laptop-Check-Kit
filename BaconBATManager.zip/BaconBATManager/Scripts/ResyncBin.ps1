# ResyncBin.ps1 - Rebuild the index from files actually present in Bin
# and optionally adopt untracked files so they can be restored.

. "$PSScriptRoot\Common.ps1"
Ensure-Folders

$bin   = Get-BinPath
$index = Load-Index
$now   = Get-Date
$root  = Get-ManagerRoot

Write-Host ""
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "  RESYNC BIN" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host ""

# Keep only entries whose file still exists
$clean = New-Object System.Collections.ArrayList
$removed = 0
foreach ($e in $index) {
    $stored = Join-Path $bin $e.StoredName
    if (Test-Path -LiteralPath $stored) {
        $expire = [datetime]::Parse($e.ExpireTime)
        if ($now -ge $expire) { $e.Status = "Expired" } else { $e.Status = "Pending" }
        [void]$clean.Add($e)
    }
    else {
        $removed++
        Write-Log "Resync removed missing entry: $($e.OriginalName)"
    }
}

# Find untracked files
$orphans = @()
if (Test-Path -LiteralPath $bin) {
    $files = Get-ChildItem -LiteralPath $bin -Filter "*.bat" -File -ErrorAction SilentlyContinue
    $known = @($clean | ForEach-Object { $_.StoredName })
    foreach ($f in $files) {
        if ($known -notcontains $f.Name) {
            $orphans += $f
        }
    }
}

Write-Host ("Tracked entries kept   : {0}" -f $clean.Count)
Write-Host ("Stale entries removed  : {0}" -f $removed)
Write-Host ("Untracked files in Bin : {0}" -f $orphans.Count)
Write-Host ""

if ($orphans.Count -gt 0) {
    Write-Host "Untracked files found:" -ForegroundColor Yellow
    foreach ($o in $orphans) {
        Write-Host ("  - {0}" -f $o.Name)
    }
    Write-Host ""
    Write-Host "These files are in the Bin but were never fully registered"
    Write-Host "(usually from an earlier bug). You can:"
    Write-Host "  A = Adopt them into the list (so you can Restore them)"
    Write-Host "  D = Delete them permanently"
    Write-Host "  S = Skip (leave them as they are)"
    Write-Host ""
    $choice = Read-Host "Choice [A/D/S]"

    if ($choice -match '^[Aa]$') {
        foreach ($o in $orphans) {
            # Try to recover original name from the stored name pattern Name__id.bat
            $origName = $o.Name
            if ($o.Name -match '^(.+)__[0-9a-fA-F]+(?:_\d+)?\.bat$') {
                $origName = $Matches[1] + ".bat"
            }
            $entry = [PSCustomObject]@{
                Id               = [guid]::NewGuid().ToString("N")
                OriginalName     = $origName
                OriginalFullPath = (Join-Path $root $origName)
                OriginalRelative = $origName
                OriginalDir      = $root
                StoredName       = $o.Name
                StoredFullPath   = $o.FullName
                MoveTime         = $o.LastWriteTime.ToString("o")
                ExpireTime       = $o.LastWriteTime.AddHours(24).ToString("o")
                Status           = "Pending"
            }
            [void]$clean.Add($entry)
            Write-Host ("Adopted: {0}  (will appear as {1})" -f $o.Name, $origName) -ForegroundColor Green
        }
        Write-Host "Adopted files can now be restored from the Bin menu."
    }
    elseif ($choice -match '^[Dd]$') {
        foreach ($o in $orphans) {
            try {
                Remove-Item -LiteralPath $o.FullName -Force -ErrorAction Stop
                Write-Host ("Deleted: {0}" -f $o.Name) -ForegroundColor Green
                Write-Log "Resync permanently deleted orphan: $($o.Name)"
            }
            catch {
                Write-Host ("Failed to delete {0}: {1}" -f $o.Name, $_) -ForegroundColor Red
            }
        }
    }
    else {
        Write-Host "Left untracked files unchanged."
    }
    Write-Host ""
}

Save-Index -Items $clean
Write-Host "Resync finished."
Write-Host ""
