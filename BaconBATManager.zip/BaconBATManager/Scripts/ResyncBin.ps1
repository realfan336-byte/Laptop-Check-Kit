# ResyncBin.ps1 - Rebuild the index from files actually present in Bin
# and remove index entries whose files are gone.
# This fixes count mismatches.

. "$PSScriptRoot\Common.ps1"
Ensure-Folders

$bin   = Get-BinPath
$index = Load-Index
$now   = Get-Date

Write-Host ""
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "  RESYNC BIN" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host ""

# Keep only entries whose file still exists
$clean = @()
$removed = 0
foreach ($e in $index) {
    $stored = Join-Path $bin $e.StoredName
    if (Test-Path -LiteralPath $stored) {
        $expire = [datetime]::Parse($e.ExpireTime)
        if ($now -ge $expire) { $e.Status = "Expired" } else { $e.Status = "Pending" }
        $clean += $e
    }
    else {
        $removed++
        Write-Log "Resync removed missing entry: $($e.OriginalName)"
    }
}

# Report orphans (files in Bin with no index entry)
$orphans = @()
if (Test-Path -LiteralPath $bin) {
    $files = Get-ChildItem -LiteralPath $bin -Filter "*.bat" -File -ErrorAction SilentlyContinue
    $known = @($clean | ForEach-Object { $_.StoredName })
    foreach ($f in $files) {
        if ($known -notcontains $f.Name) {
            $orphans += $f
        }
    }
}

Save-Index -Items $clean

Write-Host ("Index entries kept     : {0}" -f $clean.Count)
Write-Host ("Stale entries removed  : {0}" -f $removed)
Write-Host ("Untracked files in Bin : {0}" -f $orphans.Count)
Write-Host ""

if ($orphans.Count -gt 0) {
    Write-Host "Untracked files (you can delete these from the Bin folder if not needed):" -ForegroundColor Yellow
    foreach ($o in $orphans) {
        Write-Host ("  - {0}" -f $o.Name)
    }
    Write-Host ""
}

Write-Host "Resync finished. The list and the Bin folder should now match."
Write-Host ""
