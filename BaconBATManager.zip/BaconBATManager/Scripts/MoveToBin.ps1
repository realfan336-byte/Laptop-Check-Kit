# MoveToBin.ps1 - Move selected BAT files into the managed Bin
param(
    [Parameter(Mandatory=$true)]
    [string[]]$Paths,          # Full paths of files to move

    [int]$ExpireHours = 24,    # Production default 24. Use smaller value for test mode.

    [switch]$Force
)

. "$PSScriptRoot\Common.ps1"
Ensure-Folders

$root   = Get-ManagerRoot
$bin    = Get-BinPath
$index  = Load-Index
$results = @()

foreach ($p in $Paths) {
    $p = $p.Trim('"')
    $obj = [PSCustomObject]@{
        Source      = $p
        Success     = $false
        Message     = ""
        StoredName  = ""
        ExpireTime  = $null
    }

    try {
        if (-not (Test-Path -LiteralPath $p -PathType Leaf)) {
            $obj.Message = "File does not exist"
            $results += $obj
            continue
        }

        $item = Get-Item -LiteralPath $p
        if ($item.Extension -ne ".bat") {
            $obj.Message = "Not a .bat file"
            $results += $obj
            continue
        }

        # Safety: must be under manager root and not already in Bin/Data/Logs/Scripts
        if (-not (Test-IsInsideManager -FullPath $item.FullName)) {
            $obj.Message = "Path is outside the manager project folder"
            $results += $obj
            continue
        }

        $rel = Get-RelativePath -FullPath $item.FullName -BasePath $root
        $top = $rel.Split('\')[0]
        if ($top -in @("Bin","Data","Logs","Scripts") -or $item.Name -eq "BaconBATManager.bat") {
            $obj.Message = "Protected file / folder - cannot move"
            $results += $obj
            continue
        }

        # Create unique storage name to avoid collisions
        $storedName = (New-GuidName) + ".bat"
        $dest = Join-Path $bin $storedName

        if (Test-Path -LiteralPath $dest) {
            $obj.Message = "Collision in Bin (unexpected)"
            $results += $obj
            continue
        }

        $moveTime   = Get-Date
        $expireTime = $moveTime.AddHours($ExpireHours)

        # Move the file
        Move-Item -LiteralPath $item.FullName -Destination $dest -Force:$false -ErrorAction Stop

        # Record metadata
        $entry = [PSCustomObject]@{
            Id              = [guid]::NewGuid().ToString("N")
            OriginalName    = $item.Name
            OriginalFullPath= $item.FullName
            OriginalRelative= $rel
            OriginalDir     = $item.DirectoryName
            StoredName      = $storedName
            StoredFullPath  = $dest
            MoveTime        = $moveTime.ToString("o")
            ExpireTime      = $expireTime.ToString("o")
            Status          = "Pending"
        }

        $index += $entry
        $obj.Success    = $true
        $obj.Message    = "Moved successfully"
        $obj.StoredName = $storedName
        $obj.ExpireTime = $expireTime
        Write-Log "Moved to Bin: $rel -> $storedName (expires $($expireTime.ToString('yyyy-MM-dd HH:mm:ss')))"
    }
    catch {
        $obj.Message = "Move failed: $($_.Exception.Message)"
        Write-Log "Move failed for $p : $_" "ERROR"
    }

    $results += $obj
}

Save-Index -Items $index

# Human-readable summary
Write-Host ""
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "  MOVE TO BIN RESULTS" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
foreach ($r in $results) {
    if ($r.Success) {
        Write-Host ("[OK]   {0}" -f $r.Source) -ForegroundColor Green
        Write-Host ("       Expires: {0}" -f $r.ExpireTime.ToString("yyyy-MM-dd HH:mm:ss"))
    }
    else {
        Write-Host ("[FAIL] {0}" -f $r.Source) -ForegroundColor Red
        Write-Host ("       {0}" -f $r.Message)
    }
}
Write-Host ""

$results | ConvertTo-Json -Depth 4
