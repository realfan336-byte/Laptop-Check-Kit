# MoveToBin.ps1 - Move selected BAT files into the managed Bin
param(
    [Parameter(Mandatory=$true)]
    [string[]]$Paths,

    [int]$ExpireHours = 24,

    [switch]$Force
)

. "$PSScriptRoot\Common.ps1"
Ensure-Folders

$root   = Get-ManagerRoot
$bin    = Get-BinPath
$index  = Load-Index          # returns ArrayList
$results = New-Object System.Collections.ArrayList

foreach ($p in $Paths) {
    $p = $p.Trim('"')
    $obj = [PSCustomObject]@{
        Source      = $p
        Success     = $false
        Message     = ""
        StoredName  = ""
        ExpireTime  = $null
    }

    try {
        if (-not (Test-Path -LiteralPath $p -PathType Leaf)) {
            $obj.Message = "File does not exist"
            [void]$results.Add($obj)
            continue
        }

        $item = Get-Item -LiteralPath $p
        if ($item.Extension -ne ".bat") {
            $obj.Message = "Not a .bat file"
            [void]$results.Add($obj)
            continue
        }

        if (-not (Test-IsInsideManager -FullPath $item.FullName)) {
            $obj.Message = "Path is outside the manager project folder"
            [void]$results.Add($obj)
            continue
        }

        $rel = Get-RelativePath -FullPath $item.FullName -BasePath $root
        $top = $rel.Split('\')[0]
        if ($top -in @("Bin","Data","Logs","Scripts") -or $item.Name -eq "BaconBATManager.bat") {
            $obj.Message = "Protected file / folder - cannot move"
            [void]$results.Add($obj)
            continue
        }

        # Readable name: OriginalName__shortid.bat
        $shortId = (New-GuidName).Substring(0,8)
        $baseName = [System.IO.Path]::GetFileNameWithoutExtension($item.Name)
        $storedName = "{0}__{1}.bat" -f $baseName, $shortId
        $dest = Join-Path $bin $storedName

        $n = 1
        while (Test-Path -LiteralPath $dest) {
            $storedName = "{0}__{1}_{2}.bat" -f $baseName, $shortId, $n
            $dest = Join-Path $bin $storedName
            $n++
        }

        $moveTime   = Get-Date
        $expireTime = $moveTime.AddHours($ExpireHours)

        Move-Item -LiteralPath $item.FullName -Destination $dest -Force:$false -ErrorAction Stop

        $entry = [PSCustomObject]@{
            Id               = [guid]::NewGuid().ToString("N")
            OriginalName     = $item.Name
            OriginalFullPath = $item.FullName
            OriginalRelative = $rel
            OriginalDir      = $item.DirectoryName
            StoredName       = $storedName
            StoredFullPath   = $dest
            MoveTime         = $moveTime.ToString("o")
            ExpireTime       = $expireTime.ToString("o")
            Status           = "Pending"
        }

        [void]$index.Add($entry)

        $obj.Success    = $true
        $obj.Message    = "Moved successfully"
        $obj.StoredName = $storedName
        $obj.ExpireTime = $expireTime
        Write-Log "Moved to Bin: $rel -> $storedName (expires $($expireTime.ToString('yyyy-MM-dd HH:mm:ss')))"
    }
    catch {
        $obj.Message = "Move failed: $($_.Exception.Message)"
        Write-Log "Move failed for $p : $_" "ERROR"
    }

    [void]$results.Add($obj)
}

Save-Index -Items $index

Write-Host ""
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "  MOVE TO BIN - RESULTS" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
foreach ($r in $results) {
    if ($r.Success) {
        Write-Host ("[OK]  {0}" -f $r.Source) -ForegroundColor Green
        Write-Host ("      Stored as: {0}" -f $r.StoredName)
        Write-Host ("      Can be restored until: {0}" -f $r.ExpireTime.ToString("yyyy-MM-dd HH:mm"))
    }
    else {
        Write-Host ("[FAIL] {0}" -f $r.Source) -ForegroundColor Red
        Write-Host ("       {0}" -f $r.Message)
    }
}
Write-Host ""
Write-Host "Files stay recoverable for 24 hours. Use menu option 3 to restore."
Write-Host ""
