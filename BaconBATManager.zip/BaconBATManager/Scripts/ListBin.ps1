# ListBin.ps1 - Show current contents of the managed Bin with remaining time
param(
    [switch]$Quiet
)

. "$PSScriptRoot\Common.ps1"
Ensure-Folders

$index = Load-Index
$now   = Get-Date
$bin   = Get-BinPath

# Refresh status and prune missing files from index
$updated = @()
foreach ($e in $index) {
    $stored = Join-Path $bin $e.StoredName
    if (-not (Test-Path -LiteralPath $stored)) {
        Write-Log "Index entry removed (file missing): $($e.OriginalName)" "WARN"
        continue
    }

    $expire = [datetime]::Parse($e.ExpireTime)
    if ($now -ge $expire) {
        $e.Status = "Expired"
    }
    else {
        $e.Status = "Pending"
    }
    $updated += $e
}
Save-Index -Items $updated

if (-not $Quiet) {
    Write-Host ""
    Write-Host "============================================================" -ForegroundColor Cyan
    Write-Host "  BIN / RECOVERY LIST" -ForegroundColor Cyan
    Write-Host "============================================================" -ForegroundColor Cyan
    Write-Host ("Bin folder : {0}" -f $bin)
    Write-Host ("Items      : {0}" -f $updated.Count)
    Write-Host ""

    if ($updated.Count -eq 0) {
        Write-Host "Bin is empty." -ForegroundColor Yellow
    }
    else {
        $i = 1
        foreach ($e in $updated) {
            $expire = [datetime]::Parse($e.ExpireTime)
            $remain = $expire - $now
            if ($remain.TotalSeconds -lt 0) {
                $remainText = "EXPIRED - will be deleted on next cleanup"
                $color = "Red"
            }
            else {
                $h = [math]::Floor($remain.TotalHours)
                $m = $remain.Minutes
                $remainText = "{0}h {1}m remaining" -f $h, $m
                $color = "Green"
            }

            Write-Host ("  {0,3}. {1}" -f $i, $e.OriginalName) -ForegroundColor $color
            Write-Host ("       Original : {0}" -f $e.OriginalRelative)
            Write-Host ("       Moved    : {0}" -f ([datetime]::Parse($e.MoveTime).ToString("yyyy-MM-dd HH:mm")))
            Write-Host ("       Status   : {0}  ({1})" -f $e.Status, $remainText)
            Write-Host ""
            $i++
        }
    }
}

$updated | ConvertTo-Json -Depth 5
