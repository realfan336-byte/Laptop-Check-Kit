# ListBin.ps1 - Show current contents of the managed Bin with remaining time
param(
    [switch]$Quiet
)

. "$PSScriptRoot\Common.ps1"
Ensure-Folders

$index = Load-Index
$now   = Get-Date
$bin   = Get-BinPath

# --- Keep index in sync with real files on disk ---
$updated = @()
foreach ($e in $index) {
    $stored = Join-Path $bin $e.StoredName
    if (-not (Test-Path -LiteralPath $stored)) {
        Write-Log "Index entry removed (file no longer in Bin): $($e.OriginalName)" "WARN"
        continue
    }
    $expire = [datetime]::Parse($e.ExpireTime)
    if ($now -ge $expire) {
        $e.Status = "Expired"
    }
    else {
        $e.Status = "Pending"
    }
    $updated += $e
}

# Detect orphan files that are in Bin but missing from the index
$orphans = @()
if (Test-Path -LiteralPath $bin) {
    $filesInBin = Get-ChildItem -LiteralPath $bin -Filter "*.bat" -File -ErrorAction SilentlyContinue
    $knownNames = @($updated | ForEach-Object { $_.StoredName })
    foreach ($f in $filesInBin) {
        if ($knownNames -notcontains $f.Name) {
            $orphans += $f
        }
    }
}

Save-Index -Items $updated

if (-not $Quiet) {
    Write-Host ""
    Write-Host "============================================================" -ForegroundColor Cyan
    Write-Host "  BIN / RECOVERY LIST" -ForegroundColor Cyan
    Write-Host "============================================================" -ForegroundColor Cyan
    Write-Host ("Location : {0}" -f $bin)
    Write-Host ("Tracked  : {0} file(s)" -f $updated.Count)
    if ($orphans.Count -gt 0) {
        Write-Host ("Note     : {0} extra file(s) in Bin folder not in the list" -f $orphans.Count) -ForegroundColor Yellow
    }
    Write-Host ""

    if ($updated.Count -eq 0 -and $orphans.Count -eq 0) {
        Write-Host "The Bin is empty. Nothing to restore or delete." -ForegroundColor Yellow
    }
    else {
        $i = 1
        foreach ($e in $updated) {
            $expire = [datetime]::Parse($e.ExpireTime)
            $remain = $expire - $now
            if ($remain.TotalSeconds -lt 0) {
                $remainText = "EXPIRED - will be removed on next cleanup"
                $color = "Red"
            }
            else {
                $h = [math]::Floor($remain.TotalHours)
                $m = $remain.Minutes
                $remainText = "{0}h {1}m left to restore" -f $h, $m
                $color = "Green"
            }

            Write-Host ("  {0,3}. {1}" -f $i, $e.OriginalName) -ForegroundColor $color
            Write-Host ("       From     : {0}" -f $e.OriginalRelative)
            Write-Host ("       Moved    : {0}" -f ([datetime]::Parse($e.MoveTime).ToString("yyyy-MM-dd HH:mm")))
            Write-Host ("       Status   : {0}" -f $remainText)
            Write-Host ""
            $i++
        }

        if ($orphans.Count -gt 0) {
            Write-Host "Extra files found in the Bin folder (not tracked):" -ForegroundColor Yellow
            foreach ($o in $orphans) {
                Write-Host ("       - {0}" -f $o.Name)
            }
            Write-Host "You can delete them manually from the Bin folder if you do not need them."
            Write-Host ""
        }
    }
}

if ($Quiet) {
    $updated | ConvertTo-Json -Depth 5
}
