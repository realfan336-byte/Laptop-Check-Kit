@echo off
echo This is a harmless sample BAT file for testing Bacon BAT Manager.
echo It does nothing except print this message.
pause
